/*
 * Team_6.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Team_6".
 *
 * Model version              : 1.48
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan  9 17:49:04 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Team_6_h_
#define RTW_HEADER_Team_6_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef Team_6_COMMON_INCLUDES_
#define Team_6_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* Team_6_COMMON_INCLUDES_ */

#include "Team_6_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_zcfcn.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals for system '<S3>/If Action Subsystem' */
typedef struct {
  real_T In1;                          /* '<S11>/In1' */
} B_IfActionSubsystem_Team_6_T;

/* Block signals for system '<S20>/If Action Subsystem' */
typedef struct {
  real_T In1;                          /* '<S26>/In1' */
} B_IfActionSubsystem_Team_6_p_T;

/* Block signals for system '<S39>/Horizontal_Direction' */
typedef struct {
  real_T UnitDelay;                    /* '<S41>/Unit Delay' */
  real_T Add;                          /* '<S41>/Add' */
  real_T UnitDelay1;                   /* '<S41>/Unit Delay1' */
  real_T Add1;                         /* '<S41>/Add1' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem2;/* '<S41>/If Action Subsystem2' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem1;/* '<S41>/If Action Subsystem1' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem;/* '<S41>/If Action Subsystem' */
} B_Horizontal_Direction_Team_6_T;

/* Block states (default storage) for system '<S39>/Horizontal_Direction' */
typedef struct {
  real_T UnitDelay_DSTATE;             /* '<S41>/Unit Delay' */
  real_T UnitDelay1_DSTATE;            /* '<S41>/Unit Delay1' */
  int8_T check_user_input_ActiveSubsyste;/* '<S41>/check_user_input' */
} DW_Horizontal_Direction_Team__T;

/* Block signals for system '<S7>/left_mirror' */
typedef struct {
  B_IfActionSubsystem_Team_6_T IfActionSubsystem3;/* '<S67>/If Action Subsystem3' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem1;/* '<S67>/If Action Subsystem1' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem2;/* '<S67>/If Action Subsystem2' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem;/* '<S67>/If Action Subsystem' */
} B_left_mirror_Team_6_T;

/* Block states (default storage) for system '<S7>/left_mirror' */
typedef struct {
  int8_T If_ActiveSubsystem;           /* '<S67>/If' */
  boolean_T left_mirror_MODE;          /* '<S7>/left_mirror' */
} DW_left_mirror_Team_6_T;

/* Block signals for system '<S8>/Back_left_passenger' */
typedef struct {
  real_T Merge;                        /* '<S77>/Merge' */
} B_Back_left_passenger_Team_6_T;

/* Block states (default storage) for system '<S8>/Back_left_passenger' */
typedef struct {
  int8_T WindowStates_ActiveSubsystem; /* '<S77>/Window States' */
  boolean_T Back_left_passenger_MODE;  /* '<S8>/Back_left_passenger' */
} DW_Back_left_passenger_Team_6_T;

/* Block signals (default storage) */
typedef struct {
  real_T FromWs[21];                   /* '<S2>/FromWs' */
  real_T HiddenBuf_InsertedFor_HVAC_at_i;
  real_T Merge;                        /* '<S79>/Merge' */
  real_T HiddenBuf_InsertedFor_right_mir;
  real_T HiddenBuf_InsertedFor_left_mirr;
  real_T InputGain;                    /* '<S57>/Input Gain' */
  real_T SignalGenerator2;             /* '<S57>/Signal Generator2' */
  real_T SignalGenerator1;             /* '<S57>/Signal Generator1' */
  real_T SignalGenerator;              /* '<S57>/Signal Generator' */
  real_T SignalGenerator3;             /* '<S57>/Signal Generator3' */
  real_T mergingthedata;               /* '<S57>/merging the data ' */
  real_T InputGain_f;                  /* '<S58>/Input Gain' */
  real_T SignalGenerator2_m;           /* '<S58>/Signal Generator2' */
  real_T SignalGenerator1_o;           /* '<S58>/Signal Generator1' */
  real_T SignalGenerator_k;            /* '<S58>/Signal Generator' */
  real_T SignalGenerator3_m;           /* '<S58>/Signal Generator3' */
  real_T mergingthedata_e;             /* '<S58>/merging the data ' */
  real_T UnitDelay;                    /* '<S50>/Unit Delay' */
  real_T Add;                          /* '<S50>/Add' */
  real_T UnitDelay1;                   /* '<S50>/Unit Delay1' */
  real_T Add1;                         /* '<S50>/Add1' */
  real_T UnitDelay_a;                  /* '<S42>/Unit Delay' */
  real_T Add_k;                        /* '<S42>/Add' */
  real_T UnitDelay1_g;                 /* '<S42>/Unit Delay1' */
  real_T Add1_b;                       /* '<S42>/Add1' */
  real_T FromWs_l;                     /* '<S31>/FromWs' */
  real_T FromWs_j;                     /* '<S30>/FromWs' */
  real_T FromWs_jm;                    /* '<S38>/FromWs' */
  real_T FromWs_j0;                    /* '<S37>/FromWs' */
  real_T FromWs_b;                     /* '<S36>/FromWs' */
  real_T In1;                          /* '<S35>/In1' */
  real_T In1_h;                        /* '<S34>/In1' */
  real_T In1_j;                        /* '<S23>/In1' */
  real_T ContinuousPulseGenerator;     /* '<S10>/Continuous Pulse Generator' */
  boolean_T lock_control;              /* '<S1>/lock' */
  boolean_T HiddenBuf_InsertedFor_power_win;/* '<S1>/lock' */
  boolean_T Driver_priority;           /* '<S8>/Driver_priority' */
  boolean_T HiddenBuf_InsertedFor_Back_left;/* '<S8>/Driver_priority' */
  boolean_T HiddenBuf_InsertedFor_Back_righ;/* '<S8>/Driver_priority' */
  boolean_T HiddenBuf_InsertedFor_front_pas;/* '<S8>/Driver_priority' */
  boolean_T AND;                       /* '<S10>/AND' */
  boolean_T In1_i;                     /* '<S17>/In1' */
  B_Back_left_passenger_Team_6_T front_passenger;/* '<S8>/front_passenger' */
  B_Back_left_passenger_Team_6_T Back_right_passenger;/* '<S8>/Back_right_passenger' */
  B_Back_left_passenger_Team_6_T Back_left_passenger;/* '<S8>/Back_left_passenger' */
  B_left_mirror_Team_6_T right_mirror; /* '<S7>/right_mirror' */
  B_left_mirror_Team_6_T left_mirror;  /* '<S7>/left_mirror' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem2_p3;/* '<S50>/If Action Subsystem2' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem1_p;/* '<S50>/If Action Subsystem1' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem_g;/* '<S50>/If Action Subsystem' */
  B_Horizontal_Direction_Team_6_T Horizontal_Direction_m;/* '<S40>/Horizontal_Direction' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem2_a;/* '<S42>/If Action Subsystem2' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem1_d;/* '<S42>/If Action Subsystem1' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem_d;/* '<S42>/If Action Subsystem' */
  B_Horizontal_Direction_Team_6_T Horizontal_Direction;/* '<S39>/Horizontal_Direction' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem1_i;/* '<S21>/If Action Subsystem1' */
  B_IfActionSubsystem_Team_6_p_T IfActionSubsystem_j;/* '<S21>/If Action Subsystem' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem3_d;/* '<S20>/If Action Subsystem3' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem2_p;/* '<S20>/If Action Subsystem2' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem1_n;/* '<S20>/If Action Subsystem1' */
  B_IfActionSubsystem_Team_6_p_T IfActionSubsystem_m;/* '<S20>/If Action Subsystem' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem3;/* '<S19>/If Action Subsystem3' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem2;/* '<S19>/If Action Subsystem2' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem_b;/* '<S19>/If Action Subsystem' */
  B_IfActionSubsystem_Team_6_T IfActionSubsystem;/* '<S3>/If Action Subsystem' */
} B_Team_6_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay_DSTATE;             /* '<S50>/Unit Delay' */
  real_T UnitDelay1_DSTATE;            /* '<S50>/Unit Delay1' */
  real_T UnitDelay_DSTATE_e;           /* '<S42>/Unit Delay' */
  real_T UnitDelay1_DSTATE_p;          /* '<S42>/Unit Delay1' */
  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK;                      /* '<S2>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_e;                    /* '<S31>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_n;                    /* '<S30>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_d;                    /* '<S38>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_ej;                   /* '<S37>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_dg;                   /* '<S36>/FromWs' */

  int32_T clockTickCounter;            /* '<S10>/Continuous Pulse Generator' */
  struct {
    int_T PrevIndex;
  } FromWs_IWORK;                      /* '<S2>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_d;                    /* '<S31>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_f;                    /* '<S30>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_n;                    /* '<S38>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_c;                    /* '<S37>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_dt;                   /* '<S36>/FromWs' */

  int8_T WindowStates_ActiveSubsystem; /* '<S79>/Window States' */
  int8_T ifelseblock_ActiveSubsystem;  /* '<S57>/if else block' */
  int8_T ifelseblock_ActiveSubsystem_n;/* '<S58>/if else block' */
  int8_T check_user_input_ActiveSubsyste;/* '<S50>/check_user_input' */
  int8_T check_user_input_ActiveSubsys_j;/* '<S42>/check_user_input' */
  int8_T If_ActiveSubsystem;           /* '<S19>/If' */
  int8_T If_ActiveSubsystem_o;         /* '<S20>/If' */
  int8_T If_ActiveSubsystem_g;         /* '<S21>/If' */
  int8_T If_ActiveSubsystem_f;         /* '<S3>/If' */
  boolean_T power_window_MODE;         /* '<S1>/power_window' */
  boolean_T HVAC_MODE;                 /* '<S1>/HVAC' */
  DW_Back_left_passenger_Team_6_T front_passenger;/* '<S8>/front_passenger' */
  DW_Back_left_passenger_Team_6_T Back_right_passenger;/* '<S8>/Back_right_passenger' */
  DW_Back_left_passenger_Team_6_T Back_left_passenger;/* '<S8>/Back_left_passenger' */
  DW_left_mirror_Team_6_T right_mirror;/* '<S7>/right_mirror' */
  DW_left_mirror_Team_6_T left_mirror; /* '<S7>/left_mirror' */
  DW_Horizontal_Direction_Team__T Horizontal_Direction_m;/* '<S40>/Horizontal_Direction' */
  DW_Horizontal_Direction_Team__T Horizontal_Direction;/* '<S39>/Horizontal_Direction' */
} DW_Team_6_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S10>/Triggered Subsystem' */
} PrevZCX_Team_6_T;

/* Parameters for system: '<S3>/If Action Subsystem' */
struct P_IfActionSubsystem_Team_6_T_ {
  real_T Out1_Y0;                      /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S11>/Out1'
                                        */
};

/* Parameters for system: '<S20>/If Action Subsystem' */
struct P_IfActionSubsystem_Team_6_j_T_ {
  real_T Output_Y0;                    /* Computed Parameter: Output_Y0
                                        * Referenced by: '<S26>/Output'
                                        */
};

/* Parameters for system: '<S39>/Horizontal_Direction' */
struct P_Horizontal_Direction_Team_6_T_ {
  real_T Cond_check3_Value;            /* Expression: 0
                                        * Referenced by: '<S41>/Cond_check3'
                                        */
  real_T Cond_check1_Value;            /* Expression: -1
                                        * Referenced by: '<S41>/Cond_check1'
                                        */
  real_T Cond_check_Value;             /* Expression: 1
                                        * Referenced by: '<S41>/Cond_check'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S41>/Unit Delay'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S41>/Unit Delay1'
                                        */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem2;/* '<S41>/If Action Subsystem2' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem1;/* '<S41>/If Action Subsystem1' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem;/* '<S41>/If Action Subsystem' */
};

/* Parameters for system: '<S7>/left_mirror' */
struct P_left_mirror_Team_6_T_ {
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S67>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: -1
                                        * Referenced by: '<S67>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 2
                                        * Referenced by: '<S67>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<S67>/Constant4'
                                        */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem3;/* '<S67>/If Action Subsystem3' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem1;/* '<S67>/If Action Subsystem1' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem2;/* '<S67>/If Action Subsystem2' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem;/* '<S67>/If Action Subsystem' */
};

/* Parameters for system: '<S8>/Back_left_passenger' */
struct P_Back_left_passenger_Team_6_T_ {
  real_T Constant_Value;               /* Expression: 2
                                        * Referenced by: '<S77>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S77>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: -1
                                        * Referenced by: '<S77>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: -2
                                        * Referenced by: '<S77>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<S77>/Constant4'
                                        */
  real_T Merge_InitialOutput;         /* Computed Parameter: Merge_InitialOutput
                                       * Referenced by: '<S77>/Merge'
                                       */
};

/* Parameters (default storage) */
struct P_Team_6_T_ {
  real_T ContinuousPulseGenerator_Amp; /* Expression: 1
                                        * Referenced by: '<S10>/Continuous Pulse Generator'
                                        */
  real_T ContinuousPulseGenerator_Period;
                          /* Computed Parameter: ContinuousPulseGenerator_Period
                           * Referenced by: '<S10>/Continuous Pulse Generator'
                           */
  real_T ContinuousPulseGenerator_Duty;
                            /* Computed Parameter: ContinuousPulseGenerator_Duty
                             * Referenced by: '<S10>/Continuous Pulse Generator'
                             */
  real_T ContinuousPulseGenerator_PhaseD;/* Expression: 0
                                          * Referenced by: '<S10>/Continuous Pulse Generator'
                                          */
  real_T Output1_Y0;                   /* Computed Parameter: Output1_Y0
                                        * Referenced by: '<S23>/Output1'
                                        */
  real_T Output2_Y0;                   /* Computed Parameter: Output2_Y0
                                        * Referenced by: '<S34>/Output2'
                                        */
  real_T Output3_Y0;                   /* Computed Parameter: Output3_Y0
                                        * Referenced by: '<S35>/Output3'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S19>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S19>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<S19>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 1
                                        * Referenced by: '<S19>/Constant3'
                                        */
  real_T Constant_Value_c;             /* Expression: 1
                                        * Referenced by: '<S20>/Constant'
                                        */
  real_T Constant1_Value_m;            /* Expression: 0
                                        * Referenced by: '<S20>/Constant1'
                                        */
  real_T Constant1_Value_k;            /* Expression: 0
                                        * Referenced by: '<S21>/Constant1'
                                        */
  real_T Cond_check3_Value;            /* Expression: 0
                                        * Referenced by: '<S42>/Cond_check3'
                                        */
  real_T Cond_check1_Value;            /* Expression: -1
                                        * Referenced by: '<S42>/Cond_check1'
                                        */
  real_T Cond_check_Value;             /* Expression: 1
                                        * Referenced by: '<S42>/Cond_check'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S42>/Unit Delay'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S42>/Unit Delay1'
                                        */
  real_T Cond_check3_Value_h;          /* Expression: 0
                                        * Referenced by: '<S50>/Cond_check3'
                                        */
  real_T Cond_check1_Value_j;          /* Expression: -1
                                        * Referenced by: '<S50>/Cond_check1'
                                        */
  real_T Cond_check_Value_c;           /* Expression: 1
                                        * Referenced by: '<S50>/Cond_check'
                                        */
  real_T UnitDelay_InitialCondition_p; /* Expression: 0
                                        * Referenced by: '<S50>/Unit Delay'
                                        */
  real_T UnitDelay1_InitialCondition_g;/* Expression: 0
                                        * Referenced by: '<S50>/Unit Delay1'
                                        */
  real_T InputGain_Gain;               /* Expression: 20
                                        * Referenced by: '<S57>/Input Gain'
                                        */
  real_T SignalGenerator2_Amplitude;   /* Expression: 1
                                        * Referenced by: '<S57>/Signal Generator2'
                                        */
  real_T SignalGenerator2_Frequency;   /* Expression: 3
                                        * Referenced by: '<S57>/Signal Generator2'
                                        */
  real_T SignalGenerator1_Amplitude;   /* Expression: 1
                                        * Referenced by: '<S57>/Signal Generator1'
                                        */
  real_T SignalGenerator1_Frequency;   /* Expression: 2
                                        * Referenced by: '<S57>/Signal Generator1'
                                        */
  real_T SignalGenerator_Amplitude;    /* Expression: 1
                                        * Referenced by: '<S57>/Signal Generator'
                                        */
  real_T SignalGenerator_Frequency;    /* Expression: 1
                                        * Referenced by: '<S57>/Signal Generator'
                                        */
  real_T SignalGenerator3_Amplitude;   /* Expression: 1
                                        * Referenced by: '<S57>/Signal Generator3'
                                        */
  real_T SignalGenerator3_Frequency;   /* Expression: 1
                                        * Referenced by: '<S57>/Signal Generator3'
                                        */
  real_T InputGain_Gain_h;             /* Expression: 20
                                        * Referenced by: '<S58>/Input Gain'
                                        */
  real_T SignalGenerator2_Amplitude_p; /* Expression: 1
                                        * Referenced by: '<S58>/Signal Generator2'
                                        */
  real_T SignalGenerator2_Frequency_a; /* Expression: 3
                                        * Referenced by: '<S58>/Signal Generator2'
                                        */
  real_T SignalGenerator1_Amplitude_g; /* Expression: 1
                                        * Referenced by: '<S58>/Signal Generator1'
                                        */
  real_T SignalGenerator1_Frequency_g; /* Expression: 2
                                        * Referenced by: '<S58>/Signal Generator1'
                                        */
  real_T SignalGenerator_Amplitude_e;  /* Expression: 1
                                        * Referenced by: '<S58>/Signal Generator'
                                        */
  real_T SignalGenerator_Frequency_d;  /* Expression: 1
                                        * Referenced by: '<S58>/Signal Generator'
                                        */
  real_T SignalGenerator3_Amplitude_k; /* Expression: 1
                                        * Referenced by: '<S58>/Signal Generator3'
                                        */
  real_T SignalGenerator3_Frequency_i; /* Expression: 1
                                        * Referenced by: '<S58>/Signal Generator3'
                                        */
  real_T Short_Up_ip_Value;            /* Expression: 1
                                        * Referenced by: '<S79>/Short_Up_ip'
                                        */
  real_T Short_Down_ip_Value;          /* Expression: -1
                                        * Referenced by: '<S79>/Short_Down_ip'
                                        */
  real_T Long_Up_ip_Value;             /* Expression: 2
                                        * Referenced by: '<S79>/Long_Up_ip'
                                        */
  real_T Long_Down_ip_Value;           /* Expression: -2
                                        * Referenced by: '<S79>/Long_Down_ip'
                                        */
  real_T default_Value;                /* Expression: 0
                                        * Referenced by: '<S79>/default'
                                        */
  real_T Merge_InitialOutput;         /* Computed Parameter: Merge_InitialOutput
                                       * Referenced by: '<S79>/Merge'
                                       */
  boolean_T Out1_Y0;                   /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S17>/Out1'
                                        */
  P_Back_left_passenger_Team_6_T front_passenger;/* '<S8>/front_passenger' */
  P_Back_left_passenger_Team_6_T Back_right_passenger;/* '<S8>/Back_right_passenger' */
  P_Back_left_passenger_Team_6_T Back_left_passenger;/* '<S8>/Back_left_passenger' */
  P_left_mirror_Team_6_T right_mirror; /* '<S7>/right_mirror' */
  P_left_mirror_Team_6_T left_mirror;  /* '<S7>/left_mirror' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem2_p3;/* '<S50>/If Action Subsystem2' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem1_p;/* '<S50>/If Action Subsystem1' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem_g;/* '<S50>/If Action Subsystem' */
  P_Horizontal_Direction_Team_6_T Horizontal_Direction_m;/* '<S40>/Horizontal_Direction' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem2_a;/* '<S42>/If Action Subsystem2' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem1_d;/* '<S42>/If Action Subsystem1' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem_d;/* '<S42>/If Action Subsystem' */
  P_Horizontal_Direction_Team_6_T Horizontal_Direction;/* '<S39>/Horizontal_Direction' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem1_i;/* '<S21>/If Action Subsystem1' */
  P_IfActionSubsystem_Team_6_j_T IfActionSubsystem_j;/* '<S21>/If Action Subsystem' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem3_d;/* '<S20>/If Action Subsystem3' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem2_p;/* '<S20>/If Action Subsystem2' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem1_n;/* '<S20>/If Action Subsystem1' */
  P_IfActionSubsystem_Team_6_j_T IfActionSubsystem_m;/* '<S20>/If Action Subsystem' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem3;/* '<S19>/If Action Subsystem3' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem2;/* '<S19>/If Action Subsystem2' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem_b;/* '<S19>/If Action Subsystem' */
  P_IfActionSubsystem_Team_6_T IfActionSubsystem;/* '<S3>/If Action Subsystem' */
};

/* Real-time Model Data Structure */
struct tag_RTM_Team_6_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_Team_6_T Team_6_P;

/* Block signals (default storage) */
extern B_Team_6_T Team_6_B;

/* Block states (default storage) */
extern DW_Team_6_T Team_6_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_Team_6_T Team_6_PrevZCX;

/* Model entry point functions */
extern void Team_6_initialize(void);
extern void Team_6_step(void);
extern void Team_6_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Team_6_T *const Team_6_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S9>/Logical Operator' : Unused code path elimination
 * Block '<S16>/FromWs' : Unused code path elimination
 * Block '<S12>/AND' : Unused code path elimination
 * Block '<S12>/Constant' : Unused code path elimination
 * Block '<S3>/Logical Operator2' : Unused code path elimination
 * Block '<S13>/AND' : Unused code path elimination
 * Block '<S13>/Constant' : Unused code path elimination
 * Block '<S14>/Constant' : Unused code path elimination
 * Block '<S14>/Constant1' : Unused code path elimination
 * Block '<S14>/Constant2' : Unused code path elimination
 * Block '<S14>/Constant3' : Unused code path elimination
 * Block '<S14>/High' : Unused code path elimination
 * Block '<S14>/Low' : Unused code path elimination
 * Block '<S14>/Medium' : Unused code path elimination
 * Block '<S14>/Relational Operator' : Unused code path elimination
 * Block '<S14>/Relational Operator3' : Unused code path elimination
 * Block '<S15>/Constant' : Unused code path elimination
 * Block '<S15>/Constant1' : Unused code path elimination
 * Block '<S15>/Constant2' : Unused code path elimination
 * Block '<S15>/Constant3' : Unused code path elimination
 * Block '<S15>/High' : Unused code path elimination
 * Block '<S15>/Low' : Unused code path elimination
 * Block '<S15>/Medium' : Unused code path elimination
 * Block '<S15>/Relational Operator' : Unused code path elimination
 * Block '<S15>/Relational Operator3' : Unused code path elimination
 * Block '<Root>/Display' : Unused code path elimination
 * Block '<Root>/Display1' : Unused code path elimination
 * Block '<Root>/Display2' : Unused code path elimination
 * Block '<Root>/Display3' : Unused code path elimination
 * Block '<Root>/Display4' : Unused code path elimination
 * Block '<Root>/Display5' : Unused code path elimination
 * Block '<Root>/Display6' : Unused code path elimination
 * Block '<Root>/Display7' : Unused code path elimination
 * Block '<Root>/Front_H_Indicator_Lef1' : Unused code path elimination
 * Block '<Root>/Left_Indicator1_front' : Unused code path elimination
 * Block '<Root>/Left_Indicator1_rear' : Unused code path elimination
 * Block '<Root>/Rear_B_left' : Unused code path elimination
 * Block '<Root>/Rear_B_right' : Unused code path elimination
 * Block '<Root>/Rear_HIndicator_Right2' : Unused code path elimination
 * Block '<Root>/Rear_H_Indicator_Left1' : Unused code path elimination
 * Block '<Root>/Rear_H_Indicator_Right1' : Unused code path elimination
 * Block '<Root>/Right_Indicator1_front' : Unused code path elimination
 * Block '<Root>/Right_Indicator1_rear' : Unused code path elimination
 * Block '<Root>/front_light_left_high' : Unused code path elimination
 * Block '<Root>/front_light_left_low' : Unused code path elimination
 * Block '<Root>/front_light_left_medium' : Unused code path elimination
 * Block '<Root>/front_light_right_high' : Unused code path elimination
 * Block '<Root>/front_light_right_low' : Unused code path elimination
 * Block '<Root>/front_light_right_medium' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Team_6'
 * '<S1>'   : 'Team_6/BCM CAR'
 * '<S2>'   : 'Team_6/Signal Builder'
 * '<S3>'   : 'Team_6/BCM CAR/External Light'
 * '<S4>'   : 'Team_6/BCM CAR/HVAC'
 * '<S5>'   : 'Team_6/BCM CAR/Seat_subsystem'
 * '<S6>'   : 'Team_6/BCM CAR/Wiper Subsystem'
 * '<S7>'   : 'Team_6/BCM CAR/mirror'
 * '<S8>'   : 'Team_6/BCM CAR/power_window'
 * '<S9>'   : 'Team_6/BCM CAR/External Light/Brake_subsystem'
 * '<S10>'  : 'Team_6/BCM CAR/External Light/Hazard_subsystem'
 * '<S11>'  : 'Team_6/BCM CAR/External Light/If Action Subsystem'
 * '<S12>'  : 'Team_6/BCM CAR/External Light/Left_Indicator1'
 * '<S13>'  : 'Team_6/BCM CAR/External Light/Right_Indicator1'
 * '<S14>'  : 'Team_6/BCM CAR/External Light/front_light_left'
 * '<S15>'  : 'Team_6/BCM CAR/External Light/front_light_right'
 * '<S16>'  : 'Team_6/BCM CAR/External Light/Brake_subsystem/Signal Builder'
 * '<S17>'  : 'Team_6/BCM CAR/External Light/Hazard_subsystem/Triggered Subsystem'
 * '<S18>'  : 'Team_6/BCM CAR/HVAC/HVAC'
 * '<S19>'  : 'Team_6/BCM CAR/HVAC/HVAC/Cooler'
 * '<S20>'  : 'Team_6/BCM CAR/HVAC/HVAC/Heater'
 * '<S21>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent'
 * '<S22>'  : 'Team_6/BCM CAR/HVAC/HVAC/Cooler/If Action Subsystem'
 * '<S23>'  : 'Team_6/BCM CAR/HVAC/HVAC/Cooler/If Action Subsystem1'
 * '<S24>'  : 'Team_6/BCM CAR/HVAC/HVAC/Cooler/If Action Subsystem2'
 * '<S25>'  : 'Team_6/BCM CAR/HVAC/HVAC/Cooler/If Action Subsystem3'
 * '<S26>'  : 'Team_6/BCM CAR/HVAC/HVAC/Heater/If Action Subsystem'
 * '<S27>'  : 'Team_6/BCM CAR/HVAC/HVAC/Heater/If Action Subsystem1'
 * '<S28>'  : 'Team_6/BCM CAR/HVAC/HVAC/Heater/If Action Subsystem2'
 * '<S29>'  : 'Team_6/BCM CAR/HVAC/HVAC/Heater/If Action Subsystem3'
 * '<S30>'  : 'Team_6/BCM CAR/HVAC/HVAC/Heater/Signal Builder1'
 * '<S31>'  : 'Team_6/BCM CAR/HVAC/HVAC/Heater/Signal Builder2'
 * '<S32>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent/If Action Subsystem'
 * '<S33>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent/If Action Subsystem1'
 * '<S34>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent/If Action Subsystem2'
 * '<S35>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent/If Action Subsystem3'
 * '<S36>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent/Signal Builder'
 * '<S37>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent/Signal Builder1'
 * '<S38>'  : 'Team_6/BCM CAR/HVAC/HVAC/Vent/Signal Builder2'
 * '<S39>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left'
 * '<S40>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right'
 * '<S41>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Horizontal_Direction'
 * '<S42>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Vertical_Direction'
 * '<S43>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Horizontal_Direction/If Action Subsystem'
 * '<S44>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Horizontal_Direction/If Action Subsystem1'
 * '<S45>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Horizontal_Direction/If Action Subsystem2'
 * '<S46>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Vertical_Direction/If Action Subsystem'
 * '<S47>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Vertical_Direction/If Action Subsystem1'
 * '<S48>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Left/Vertical_Direction/If Action Subsystem2'
 * '<S49>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Horizontal_Direction'
 * '<S50>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Vertical_Direction'
 * '<S51>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Horizontal_Direction/If Action Subsystem'
 * '<S52>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Horizontal_Direction/If Action Subsystem1'
 * '<S53>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Horizontal_Direction/If Action Subsystem2'
 * '<S54>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Vertical_Direction/If Action Subsystem'
 * '<S55>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Vertical_Direction/If Action Subsystem1'
 * '<S56>'  : 'Team_6/BCM CAR/Seat_subsystem/Front_Right/Vertical_Direction/If Action Subsystem2'
 * '<S57>'  : 'Team_6/BCM CAR/Wiper Subsystem/First wiper'
 * '<S58>'  : 'Team_6/BCM CAR/Wiper Subsystem/Secod wiper'
 * '<S59>'  : 'Team_6/BCM CAR/Wiper Subsystem/First wiper/If Action Subsystem'
 * '<S60>'  : 'Team_6/BCM CAR/Wiper Subsystem/First wiper/If Action Subsystem1'
 * '<S61>'  : 'Team_6/BCM CAR/Wiper Subsystem/First wiper/If Action Subsystem2'
 * '<S62>'  : 'Team_6/BCM CAR/Wiper Subsystem/First wiper/If Action Subsystem3'
 * '<S63>'  : 'Team_6/BCM CAR/Wiper Subsystem/Secod wiper/If Action Subsystem'
 * '<S64>'  : 'Team_6/BCM CAR/Wiper Subsystem/Secod wiper/If Action Subsystem1'
 * '<S65>'  : 'Team_6/BCM CAR/Wiper Subsystem/Secod wiper/If Action Subsystem2'
 * '<S66>'  : 'Team_6/BCM CAR/Wiper Subsystem/Secod wiper/If Action Subsystem3'
 * '<S67>'  : 'Team_6/BCM CAR/mirror/left_mirror'
 * '<S68>'  : 'Team_6/BCM CAR/mirror/right_mirror'
 * '<S69>'  : 'Team_6/BCM CAR/mirror/left_mirror/If Action Subsystem'
 * '<S70>'  : 'Team_6/BCM CAR/mirror/left_mirror/If Action Subsystem1'
 * '<S71>'  : 'Team_6/BCM CAR/mirror/left_mirror/If Action Subsystem2'
 * '<S72>'  : 'Team_6/BCM CAR/mirror/left_mirror/If Action Subsystem3'
 * '<S73>'  : 'Team_6/BCM CAR/mirror/right_mirror/If Action Subsystem'
 * '<S74>'  : 'Team_6/BCM CAR/mirror/right_mirror/If Action Subsystem1'
 * '<S75>'  : 'Team_6/BCM CAR/mirror/right_mirror/If Action Subsystem2'
 * '<S76>'  : 'Team_6/BCM CAR/mirror/right_mirror/If Action Subsystem3'
 * '<S77>'  : 'Team_6/BCM CAR/power_window/Back_left_passenger'
 * '<S78>'  : 'Team_6/BCM CAR/power_window/Back_right_passenger'
 * '<S79>'  : 'Team_6/BCM CAR/power_window/driver_button'
 * '<S80>'  : 'Team_6/BCM CAR/power_window/front_passenger'
 * '<S81>'  : 'Team_6/BCM CAR/power_window/Back_left_passenger/Do Nothing'
 * '<S82>'  : 'Team_6/BCM CAR/power_window/Back_left_passenger/Long Down'
 * '<S83>'  : 'Team_6/BCM CAR/power_window/Back_left_passenger/Long Up'
 * '<S84>'  : 'Team_6/BCM CAR/power_window/Back_left_passenger/Short Down'
 * '<S85>'  : 'Team_6/BCM CAR/power_window/Back_left_passenger/Short Up'
 * '<S86>'  : 'Team_6/BCM CAR/power_window/Back_right_passenger/Do Nothing'
 * '<S87>'  : 'Team_6/BCM CAR/power_window/Back_right_passenger/Long Down'
 * '<S88>'  : 'Team_6/BCM CAR/power_window/Back_right_passenger/Long Up'
 * '<S89>'  : 'Team_6/BCM CAR/power_window/Back_right_passenger/Short Down'
 * '<S90>'  : 'Team_6/BCM CAR/power_window/Back_right_passenger/Short Up'
 * '<S91>'  : 'Team_6/BCM CAR/power_window/driver_button/Do_Nothing'
 * '<S92>'  : 'Team_6/BCM CAR/power_window/driver_button/Long_Down'
 * '<S93>'  : 'Team_6/BCM CAR/power_window/driver_button/Long_Up'
 * '<S94>'  : 'Team_6/BCM CAR/power_window/driver_button/Short_Down'
 * '<S95>'  : 'Team_6/BCM CAR/power_window/driver_button/Short_Up'
 * '<S96>'  : 'Team_6/BCM CAR/power_window/front_passenger/Do Nothing'
 * '<S97>'  : 'Team_6/BCM CAR/power_window/front_passenger/Long Down'
 * '<S98>'  : 'Team_6/BCM CAR/power_window/front_passenger/Long Up'
 * '<S99>'  : 'Team_6/BCM CAR/power_window/front_passenger/Short Down'
 * '<S100>' : 'Team_6/BCM CAR/power_window/front_passenger/Short Up'
 */
#endif                                 /* RTW_HEADER_Team_6_h_ */
