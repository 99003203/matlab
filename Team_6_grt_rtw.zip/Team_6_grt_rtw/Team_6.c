/*
 * Team_6.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Team_6".
 *
 * Model version              : 1.48
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan  9 17:49:04 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "Team_6.h"
#include "Team_6_private.h"

/* Block signals (default storage) */
B_Team_6_T Team_6_B;

/* Block states (default storage) */
DW_Team_6_T Team_6_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_Team_6_T Team_6_PrevZCX;

/* Real-time model */
static RT_MODEL_Team_6_T Team_6_M_;
RT_MODEL_Team_6_T *const Team_6_M = &Team_6_M_;

/*
 * System initialize for action system:
 *    '<S3>/If Action Subsystem'
 *    '<S19>/If Action Subsystem'
 *    '<S19>/If Action Subsystem2'
 *    '<S19>/If Action Subsystem3'
 *    '<S20>/If Action Subsystem1'
 *    '<S20>/If Action Subsystem2'
 *    '<S20>/If Action Subsystem3'
 *    '<S21>/If Action Subsystem1'
 *    '<S41>/If Action Subsystem'
 *    '<S41>/If Action Subsystem1'
 *    ...
 */
void Team_6_IfActionSubsystem_Init(B_IfActionSubsystem_Team_6_T *localB,
  P_IfActionSubsystem_Team_6_T *localP)
{
  /* SystemInitialize for Outport: '<S11>/Out1' incorporates:
   *  Inport: '<S11>/In1'
   */
  localB->In1 = localP->Out1_Y0;
}

/*
 * Output and update for action system:
 *    '<S3>/If Action Subsystem'
 *    '<S19>/If Action Subsystem'
 *    '<S19>/If Action Subsystem2'
 *    '<S19>/If Action Subsystem3'
 *    '<S20>/If Action Subsystem1'
 *    '<S20>/If Action Subsystem2'
 *    '<S20>/If Action Subsystem3'
 *    '<S21>/If Action Subsystem1'
 *    '<S41>/If Action Subsystem'
 *    '<S41>/If Action Subsystem1'
 *    ...
 */
void Team_6_IfActionSubsystem(real_T rtu_In1, B_IfActionSubsystem_Team_6_T
  *localB)
{
  /* Inport: '<S11>/In1' */
  localB->In1 = rtu_In1;
}

/*
 * System initialize for action system:
 *    '<S20>/If Action Subsystem'
 *    '<S21>/If Action Subsystem'
 */
void Team_6_IfActionSubsystem_f_Init(B_IfActionSubsystem_Team_6_p_T *localB,
  P_IfActionSubsystem_Team_6_j_T *localP)
{
  /* SystemInitialize for Outport: '<S26>/Output' incorporates:
   *  Inport: '<S26>/In1'
   */
  localB->In1 = localP->Output_Y0;
}

/*
 * Output and update for action system:
 *    '<S20>/If Action Subsystem'
 *    '<S21>/If Action Subsystem'
 */
void Team_6_IfActionSubsystem_m(real_T rtu_In1, B_IfActionSubsystem_Team_6_p_T
  *localB)
{
  /* Inport: '<S26>/In1' */
  localB->In1 = rtu_In1;
}

/*
 * System initialize for atomic system:
 *    '<S39>/Horizontal_Direction'
 *    '<S40>/Horizontal_Direction'
 */
void Team__Horizontal_Direction_Init(B_Horizontal_Direction_Team_6_T *localB,
  DW_Horizontal_Direction_Team__T *localDW, P_Horizontal_Direction_Team_6_T
  *localP)
{
  /* Start for If: '<S41>/check_user_input' */
  localDW->check_user_input_ActiveSubsyste = -1;

  /* InitializeConditions for UnitDelay: '<S41>/Unit Delay' */
  localDW->UnitDelay_DSTATE = localP->UnitDelay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S41>/Unit Delay1' */
  localDW->UnitDelay1_DSTATE = localP->UnitDelay1_InitialCondition;

  /* SystemInitialize for IfAction SubSystem: '<S41>/If Action Subsystem' */
  Team_6_IfActionSubsystem_Init(&localB->IfActionSubsystem,
    &localP->IfActionSubsystem);

  /* End of SystemInitialize for SubSystem: '<S41>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S41>/If Action Subsystem1' */
  Team_6_IfActionSubsystem_Init(&localB->IfActionSubsystem1,
    &localP->IfActionSubsystem1);

  /* End of SystemInitialize for SubSystem: '<S41>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S41>/If Action Subsystem2' */
  Team_6_IfActionSubsystem_Init(&localB->IfActionSubsystem2,
    &localP->IfActionSubsystem2);

  /* End of SystemInitialize for SubSystem: '<S41>/If Action Subsystem2' */
}

/*
 * Outputs for atomic system:
 *    '<S39>/Horizontal_Direction'
 *    '<S40>/Horizontal_Direction'
 */
void Team_6_Horizontal_Direction(real_T rtu_In1, B_Horizontal_Direction_Team_6_T
  *localB, DW_Horizontal_Direction_Team__T *localDW,
  P_Horizontal_Direction_Team_6_T *localP)
{
  int8_T rtAction;

  /* If: '<S41>/check_user_input' incorporates:
   *  Constant: '<S41>/Cond_check'
   *  Constant: '<S41>/Cond_check1'
   *  Constant: '<S41>/Cond_check3'
   */
  if (rtu_In1 == 1.0) {
    rtAction = 0;

    /* Outputs for IfAction SubSystem: '<S41>/If Action Subsystem' incorporates:
     *  ActionPort: '<S43>/Action Port'
     */
    Team_6_IfActionSubsystem(localP->Cond_check_Value,
      &localB->IfActionSubsystem);

    /* End of Outputs for SubSystem: '<S41>/If Action Subsystem' */
  } else if (rtu_In1 == -1.0) {
    rtAction = 1;

    /* Outputs for IfAction SubSystem: '<S41>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S44>/Action Port'
     */
    Team_6_IfActionSubsystem(localP->Cond_check1_Value,
      &localB->IfActionSubsystem1);

    /* End of Outputs for SubSystem: '<S41>/If Action Subsystem1' */
  } else {
    rtAction = 2;

    /* Outputs for IfAction SubSystem: '<S41>/If Action Subsystem2' incorporates:
     *  ActionPort: '<S45>/Action Port'
     */
    Team_6_IfActionSubsystem(localP->Cond_check3_Value,
      &localB->IfActionSubsystem2);

    /* End of Outputs for SubSystem: '<S41>/If Action Subsystem2' */
  }

  localDW->check_user_input_ActiveSubsyste = rtAction;

  /* End of If: '<S41>/check_user_input' */

  /* UnitDelay: '<S41>/Unit Delay' */
  localB->UnitDelay = localDW->UnitDelay_DSTATE;

  /* Sum: '<S41>/Add' */
  localB->Add = localB->IfActionSubsystem.In1 + localB->UnitDelay;

  /* UnitDelay: '<S41>/Unit Delay1' */
  localB->UnitDelay1 = localDW->UnitDelay1_DSTATE;

  /* Sum: '<S41>/Add1' */
  localB->Add1 = localB->IfActionSubsystem1.In1 + localB->UnitDelay1;
}

/*
 * Update for atomic system:
 *    '<S39>/Horizontal_Direction'
 *    '<S40>/Horizontal_Direction'
 */
void Tea_Horizontal_Direction_Update(B_Horizontal_Direction_Team_6_T *localB,
  DW_Horizontal_Direction_Team__T *localDW)
{
  /* Update for UnitDelay: '<S41>/Unit Delay' */
  localDW->UnitDelay_DSTATE = localB->Add;

  /* Update for UnitDelay: '<S41>/Unit Delay1' */
  localDW->UnitDelay1_DSTATE = localB->Add1;
}

/*
 * Output and update for action system:
 *    '<S57>/If Action Subsystem'
 *    '<S57>/If Action Subsystem1'
 *    '<S57>/If Action Subsystem2'
 *    '<S57>/If Action Subsystem3'
 *    '<S58>/If Action Subsystem'
 *    '<S58>/If Action Subsystem1'
 *    '<S58>/If Action Subsystem2'
 *    '<S58>/If Action Subsystem3'
 *    '<S77>/Long Up'
 *    '<S77>/Short Up'
 *    ...
 */
void Team_6_IfActionSubsystem_e(real_T rtu_In1, real_T *rty_Out1)
{
  /* Inport: '<S59>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * System initialize for enable system:
 *    '<S7>/left_mirror'
 *    '<S7>/right_mirror'
 */
void Team_6_left_mirror_Init(B_left_mirror_Team_6_T *localB,
  DW_left_mirror_Team_6_T *localDW, P_left_mirror_Team_6_T *localP)
{
  /* Start for If: '<S67>/If' */
  localDW->If_ActiveSubsystem = -1;

  /* SystemInitialize for IfAction SubSystem: '<S67>/If Action Subsystem' */
  Team_6_IfActionSubsystem_Init(&localB->IfActionSubsystem,
    &localP->IfActionSubsystem);

  /* End of SystemInitialize for SubSystem: '<S67>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S67>/If Action Subsystem2' */
  Team_6_IfActionSubsystem_Init(&localB->IfActionSubsystem2,
    &localP->IfActionSubsystem2);

  /* End of SystemInitialize for SubSystem: '<S67>/If Action Subsystem2' */

  /* SystemInitialize for IfAction SubSystem: '<S67>/If Action Subsystem1' */
  Team_6_IfActionSubsystem_Init(&localB->IfActionSubsystem1,
    &localP->IfActionSubsystem1);

  /* End of SystemInitialize for SubSystem: '<S67>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S67>/If Action Subsystem3' */
  Team_6_IfActionSubsystem_Init(&localB->IfActionSubsystem3,
    &localP->IfActionSubsystem3);

  /* End of SystemInitialize for SubSystem: '<S67>/If Action Subsystem3' */
}

/*
 * Disable for enable system:
 *    '<S7>/left_mirror'
 *    '<S7>/right_mirror'
 */
void Team_6_left_mirror_Disable(DW_left_mirror_Team_6_T *localDW)
{
  /* Disable for If: '<S67>/If' */
  localDW->If_ActiveSubsystem = -1;
  localDW->left_mirror_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S7>/left_mirror'
 *    '<S7>/right_mirror'
 */
void Team_6_left_mirror(real_T rtu_Enable, real_T rtu_Input2,
  B_left_mirror_Team_6_T *localB, DW_left_mirror_Team_6_T *localDW,
  P_left_mirror_Team_6_T *localP)
{
  int8_T rtAction;

  /* Outputs for Enabled SubSystem: '<S7>/left_mirror' incorporates:
   *  EnablePort: '<S67>/Enable'
   */
  if (rtu_Enable > 0.0) {
    localDW->left_mirror_MODE = true;
  } else {
    if (localDW->left_mirror_MODE) {
      Team_6_left_mirror_Disable(localDW);
    }
  }

  if (localDW->left_mirror_MODE) {
    /* If: '<S67>/If' incorporates:
     *  Constant: '<S67>/Constant1'
     *  Constant: '<S67>/Constant2'
     *  Constant: '<S67>/Constant3'
     *  Constant: '<S67>/Constant4'
     */
    if (rtu_Input2 == 1.0) {
      rtAction = 0;

      /* Outputs for IfAction SubSystem: '<S67>/If Action Subsystem' incorporates:
       *  ActionPort: '<S69>/Action Port'
       */
      Team_6_IfActionSubsystem(localP->Constant1_Value,
        &localB->IfActionSubsystem);

      /* End of Outputs for SubSystem: '<S67>/If Action Subsystem' */
    } else if (rtu_Input2 == -1.0) {
      rtAction = 1;

      /* Outputs for IfAction SubSystem: '<S67>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S71>/Action Port'
       */
      Team_6_IfActionSubsystem(localP->Constant2_Value,
        &localB->IfActionSubsystem2);

      /* End of Outputs for SubSystem: '<S67>/If Action Subsystem2' */
    } else if (rtu_Input2 == 2.0) {
      rtAction = 2;

      /* Outputs for IfAction SubSystem: '<S67>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S70>/Action Port'
       */
      Team_6_IfActionSubsystem(localP->Constant3_Value,
        &localB->IfActionSubsystem1);

      /* End of Outputs for SubSystem: '<S67>/If Action Subsystem1' */
    } else {
      rtAction = 3;

      /* Outputs for IfAction SubSystem: '<S67>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S72>/Action Port'
       */
      Team_6_IfActionSubsystem(localP->Constant4_Value,
        &localB->IfActionSubsystem3);

      /* End of Outputs for SubSystem: '<S67>/If Action Subsystem3' */
    }

    localDW->If_ActiveSubsystem = rtAction;

    /* End of If: '<S67>/If' */
  }

  /* End of Outputs for SubSystem: '<S7>/left_mirror' */
}

/*
 * System initialize for enable system:
 *    '<S8>/Back_left_passenger'
 *    '<S8>/Back_right_passenger'
 *    '<S8>/front_passenger'
 */
void Team_6_Back_left_passenger_Init(B_Back_left_passenger_Team_6_T *localB,
  DW_Back_left_passenger_Team_6_T *localDW, P_Back_left_passenger_Team_6_T
  *localP)
{
  /* Start for SwitchCase: '<S77>/Window States' */
  localDW->WindowStates_ActiveSubsystem = -1;

  /* SystemInitialize for Merge: '<S77>/Merge' */
  localB->Merge = localP->Merge_InitialOutput;
}

/*
 * Disable for enable system:
 *    '<S8>/Back_left_passenger'
 *    '<S8>/Back_right_passenger'
 *    '<S8>/front_passenger'
 */
void Tea_Back_left_passenger_Disable(DW_Back_left_passenger_Team_6_T *localDW)
{
  /* Disable for SwitchCase: '<S77>/Window States' */
  localDW->WindowStates_ActiveSubsystem = -1;
  localDW->Back_left_passenger_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S8>/Back_left_passenger'
 *    '<S8>/Back_right_passenger'
 *    '<S8>/front_passenger'
 */
void Team_6_Back_left_passenger(boolean_T rtu_Enable, real_T rtu_Input,
  B_Back_left_passenger_Team_6_T *localB, DW_Back_left_passenger_Team_6_T
  *localDW, P_Back_left_passenger_Team_6_T *localP)
{
  real_T tmp;
  int8_T rtAction;

  /* Outputs for Enabled SubSystem: '<S8>/Back_left_passenger' incorporates:
   *  EnablePort: '<S77>/Enable'
   */
  if (rtu_Enable) {
    localDW->Back_left_passenger_MODE = true;
  } else {
    if (localDW->Back_left_passenger_MODE) {
      Tea_Back_left_passenger_Disable(localDW);
    }
  }

  if (localDW->Back_left_passenger_MODE) {
    /* SwitchCase: '<S77>/Window States' incorporates:
     *  Constant: '<S77>/Constant'
     *  Constant: '<S77>/Constant1'
     *  Constant: '<S77>/Constant2'
     *  Constant: '<S77>/Constant3'
     *  Constant: '<S77>/Constant4'
     */
    tmp = trunc(rtu_Input);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = fmod(tmp, 4.294967296E+9);
    }

    switch (tmp < 0.0 ? -(int32_T)(uint32_T)-tmp : (int32_T)(uint32_T)tmp) {
     case 1:
      rtAction = 0;
      break;

     case 2:
      rtAction = 1;
      break;

     case 3:
      rtAction = 2;
      break;

     case 4:
      rtAction = 3;
      break;

     default:
      rtAction = 4;
      break;
    }

    localDW->WindowStates_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S77>/Long Up' incorporates:
       *  ActionPort: '<S83>/Action Port'
       */
      Team_6_IfActionSubsystem_e(localP->Constant_Value, &localB->Merge);

      /* End of Outputs for SubSystem: '<S77>/Long Up' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S77>/Short Up' incorporates:
       *  ActionPort: '<S85>/Action Port'
       */
      Team_6_IfActionSubsystem_e(localP->Constant1_Value, &localB->Merge);

      /* End of Outputs for SubSystem: '<S77>/Short Up' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S77>/Short Down' incorporates:
       *  ActionPort: '<S84>/Action Port'
       */
      Team_6_IfActionSubsystem_e(localP->Constant2_Value, &localB->Merge);

      /* End of Outputs for SubSystem: '<S77>/Short Down' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S77>/Long Down' incorporates:
       *  ActionPort: '<S82>/Action Port'
       */
      Team_6_IfActionSubsystem_e(localP->Constant3_Value, &localB->Merge);

      /* End of Outputs for SubSystem: '<S77>/Long Down' */
      break;

     default:
      /* Outputs for IfAction SubSystem: '<S77>/Do Nothing' incorporates:
       *  ActionPort: '<S81>/Action Port'
       */
      Team_6_IfActionSubsystem_e(localP->Constant4_Value, &localB->Merge);

      /* End of Outputs for SubSystem: '<S77>/Do Nothing' */
      break;
    }

    /* End of SwitchCase: '<S77>/Window States' */
  }

  /* End of Outputs for SubSystem: '<S8>/Back_left_passenger' */
}

/* Model step function */
void Team_6_step(void)
{
  real_T tmp;
  int8_T rtAction;
  ZCEventType zcEvent;

  /* FromWorkspace: '<S2>/FromWs' */
  {
    real_T *pDataValues = (real_T *) Team_6_DW.FromWs_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) Team_6_DW.FromWs_PWORK.TimePtr;
    int_T currTimeIndex = Team_6_DW.FromWs_IWORK.PrevIndex;
    real_T t = Team_6_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[45]) {
      currTimeIndex = 44;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    Team_6_DW.FromWs_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          {
            int_T elIdx;
            for (elIdx = 0; elIdx < 21; ++elIdx) {
              (&Team_6_B.FromWs[0])[elIdx] = pDataValues[currTimeIndex];
              pDataValues += 46;
            }
          }
        } else {
          {
            int_T elIdx;
            for (elIdx = 0; elIdx < 21; ++elIdx) {
              (&Team_6_B.FromWs[0])[elIdx] = pDataValues[currTimeIndex + 1];
              pDataValues += 46;
            }
          }
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;

        {
          int_T elIdx;
          for (elIdx = 0; elIdx < 21; ++elIdx) {
            d1 = pDataValues[TimeIndex];
            d2 = pDataValues[TimeIndex + 1];
            (&Team_6_B.FromWs[0])[elIdx] = (real_T) rtInterpolate(d1, d2, f1, f2);
            pDataValues += 46;
          }
        }
      }
    }
  }

  /* SignalConversion generated from: '<S4>/Enable' */
  Team_6_B.HiddenBuf_InsertedFor_HVAC_at_i = Team_6_B.FromWs[9];

  /* Outputs for Enabled SubSystem: '<S1>/HVAC' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  if (Team_6_B.HiddenBuf_InsertedFor_HVAC_at_i > 0.0) {
    Team_6_DW.HVAC_MODE = true;
  } else {
    if (Team_6_DW.HVAC_MODE) {
      /* Disable for If: '<S19>/If' */
      Team_6_DW.If_ActiveSubsystem = -1;

      /* Disable for If: '<S20>/If' */
      Team_6_DW.If_ActiveSubsystem_o = -1;

      /* Disable for If: '<S21>/If' */
      Team_6_DW.If_ActiveSubsystem_g = -1;
      Team_6_DW.HVAC_MODE = false;
    }
  }

  if (Team_6_DW.HVAC_MODE) {
    /* If: '<S19>/If' incorporates:
     *  Constant: '<S19>/Constant'
     *  Constant: '<S19>/Constant1'
     *  Constant: '<S19>/Constant2'
     *  Constant: '<S19>/Constant3'
     *  Inport: '<S23>/In1'
     */
    if (Team_6_B.FromWs[6] == 1.0) {
      rtAction = 0;

      /* Outputs for IfAction SubSystem: '<S19>/If Action Subsystem' incorporates:
       *  ActionPort: '<S22>/Action Port'
       */
      Team_6_IfActionSubsystem(Team_6_P.Constant_Value,
        &Team_6_B.IfActionSubsystem_b);

      /* End of Outputs for SubSystem: '<S19>/If Action Subsystem' */
    } else if (Team_6_B.FromWs[6] == 2.0) {
      rtAction = 1;

      /* Outputs for IfAction SubSystem: '<S19>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S23>/Action Port'
       */
      Team_6_B.In1_j = Team_6_P.Constant2_Value;

      /* End of Outputs for SubSystem: '<S19>/If Action Subsystem1' */
    } else if (Team_6_B.FromWs[6] == 3.0) {
      rtAction = 2;

      /* Outputs for IfAction SubSystem: '<S19>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S24>/Action Port'
       */
      Team_6_IfActionSubsystem(Team_6_P.Constant3_Value,
        &Team_6_B.IfActionSubsystem2);

      /* End of Outputs for SubSystem: '<S19>/If Action Subsystem2' */
    } else {
      rtAction = 3;

      /* Outputs for IfAction SubSystem: '<S19>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S25>/Action Port'
       */
      Team_6_IfActionSubsystem(Team_6_P.Constant1_Value,
        &Team_6_B.IfActionSubsystem3);

      /* End of Outputs for SubSystem: '<S19>/If Action Subsystem3' */
    }

    Team_6_DW.If_ActiveSubsystem = rtAction;

    /* End of If: '<S19>/If' */

    /* FromWorkspace: '<S31>/FromWs' */
    {
      real_T *pDataValues = (real_T *) Team_6_DW.FromWs_PWORK_e.DataPtr;
      real_T *pTimeValues = (real_T *) Team_6_DW.FromWs_PWORK_e.TimePtr;
      int_T currTimeIndex = Team_6_DW.FromWs_IWORK_d.PrevIndex;
      real_T t = Team_6_M->Timing.t[0];

      /* Get index */
      if (t <= pTimeValues[0]) {
        currTimeIndex = 0;
      } else if (t >= pTimeValues[39]) {
        currTimeIndex = 38;
      } else {
        if (t < pTimeValues[currTimeIndex]) {
          while (t < pTimeValues[currTimeIndex]) {
            currTimeIndex--;
          }
        } else {
          while (t >= pTimeValues[currTimeIndex + 1]) {
            currTimeIndex++;
          }
        }
      }

      Team_6_DW.FromWs_IWORK_d.PrevIndex = currTimeIndex;

      /* Post output */
      {
        real_T t1 = pTimeValues[currTimeIndex];
        real_T t2 = pTimeValues[currTimeIndex + 1];
        if (t1 == t2) {
          if (t < t1) {
            Team_6_B.FromWs_l = pDataValues[currTimeIndex];
          } else {
            Team_6_B.FromWs_l = pDataValues[currTimeIndex + 1];
          }
        } else {
          real_T f1 = (t2 - t) / (t2 - t1);
          real_T f2 = 1.0 - f1;
          real_T d1;
          real_T d2;
          int_T TimeIndex= currTimeIndex;
          d1 = pDataValues[TimeIndex];
          d2 = pDataValues[TimeIndex + 1];
          Team_6_B.FromWs_l = (real_T) rtInterpolate(d1, d2, f1, f2);
          pDataValues += 40;
        }
      }
    }

    /* FromWorkspace: '<S30>/FromWs' */
    {
      real_T *pDataValues = (real_T *) Team_6_DW.FromWs_PWORK_n.DataPtr;
      real_T *pTimeValues = (real_T *) Team_6_DW.FromWs_PWORK_n.TimePtr;
      int_T currTimeIndex = Team_6_DW.FromWs_IWORK_f.PrevIndex;
      real_T t = Team_6_M->Timing.t[0];

      /* Get index */
      if (t <= pTimeValues[0]) {
        currTimeIndex = 0;
      } else if (t >= pTimeValues[39]) {
        currTimeIndex = 38;
      } else {
        if (t < pTimeValues[currTimeIndex]) {
          while (t < pTimeValues[currTimeIndex]) {
            currTimeIndex--;
          }
        } else {
          while (t >= pTimeValues[currTimeIndex + 1]) {
            currTimeIndex++;
          }
        }
      }

      Team_6_DW.FromWs_IWORK_f.PrevIndex = currTimeIndex;

      /* Post output */
      {
        real_T t1 = pTimeValues[currTimeIndex];
        real_T t2 = pTimeValues[currTimeIndex + 1];
        if (t1 == t2) {
          if (t < t1) {
            Team_6_B.FromWs_j = pDataValues[currTimeIndex];
          } else {
            Team_6_B.FromWs_j = pDataValues[currTimeIndex + 1];
          }
        } else {
          real_T f1 = (t2 - t) / (t2 - t1);
          real_T f2 = 1.0 - f1;
          real_T d1;
          real_T d2;
          int_T TimeIndex= currTimeIndex;
          d1 = pDataValues[TimeIndex];
          d2 = pDataValues[TimeIndex + 1];
          Team_6_B.FromWs_j = (real_T) rtInterpolate(d1, d2, f1, f2);
          pDataValues += 40;
        }
      }
    }

    /* If: '<S20>/If' incorporates:
     *  Constant: '<S20>/Constant'
     *  Constant: '<S20>/Constant1'
     */
    if (Team_6_B.FromWs[7] == 1.0) {
      rtAction = 0;

      /* Outputs for IfAction SubSystem: '<S20>/If Action Subsystem' incorporates:
       *  ActionPort: '<S26>/Action Port'
       */
      Team_6_IfActionSubsystem_m(Team_6_P.Constant_Value_c,
        &Team_6_B.IfActionSubsystem_m);

      /* End of Outputs for SubSystem: '<S20>/If Action Subsystem' */
    } else if (Team_6_B.FromWs[7] == 2.0) {
      rtAction = 1;

      /* Outputs for IfAction SubSystem: '<S20>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S27>/Action Port'
       */
      Team_6_IfActionSubsystem(Team_6_B.FromWs_j, &Team_6_B.IfActionSubsystem1_n);

      /* End of Outputs for SubSystem: '<S20>/If Action Subsystem1' */
    } else if (Team_6_B.FromWs[7] == 3.0) {
      rtAction = 2;

      /* Outputs for IfAction SubSystem: '<S20>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S28>/Action Port'
       */
      Team_6_IfActionSubsystem(Team_6_B.FromWs_l, &Team_6_B.IfActionSubsystem2_p);

      /* End of Outputs for SubSystem: '<S20>/If Action Subsystem2' */
    } else {
      rtAction = 3;

      /* Outputs for IfAction SubSystem: '<S20>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S29>/Action Port'
       */
      Team_6_IfActionSubsystem(Team_6_P.Constant1_Value_m,
        &Team_6_B.IfActionSubsystem3_d);

      /* End of Outputs for SubSystem: '<S20>/If Action Subsystem3' */
    }

    Team_6_DW.If_ActiveSubsystem_o = rtAction;

    /* End of If: '<S20>/If' */

    /* FromWorkspace: '<S38>/FromWs' */
    {
      real_T *pDataValues = (real_T *) Team_6_DW.FromWs_PWORK_d.DataPtr;
      real_T *pTimeValues = (real_T *) Team_6_DW.FromWs_PWORK_d.TimePtr;
      int_T currTimeIndex = Team_6_DW.FromWs_IWORK_n.PrevIndex;
      real_T t = Team_6_M->Timing.t[0];

      /* Get index */
      if (t <= pTimeValues[0]) {
        currTimeIndex = 0;
      } else if (t >= pTimeValues[39]) {
        currTimeIndex = 38;
      } else {
        if (t < pTimeValues[currTimeIndex]) {
          while (t < pTimeValues[currTimeIndex]) {
            currTimeIndex--;
          }
        } else {
          while (t >= pTimeValues[currTimeIndex + 1]) {
            currTimeIndex++;
          }
        }
      }

      Team_6_DW.FromWs_IWORK_n.PrevIndex = currTimeIndex;

      /* Post output */
      {
        real_T t1 = pTimeValues[currTimeIndex];
        real_T t2 = pTimeValues[currTimeIndex + 1];
        if (t1 == t2) {
          if (t < t1) {
            Team_6_B.FromWs_jm = pDataValues[currTimeIndex];
          } else {
            Team_6_B.FromWs_jm = pDataValues[currTimeIndex + 1];
          }
        } else {
          real_T f1 = (t2 - t) / (t2 - t1);
          real_T f2 = 1.0 - f1;
          real_T d1;
          real_T d2;
          int_T TimeIndex= currTimeIndex;
          d1 = pDataValues[TimeIndex];
          d2 = pDataValues[TimeIndex + 1];
          Team_6_B.FromWs_jm = (real_T) rtInterpolate(d1, d2, f1, f2);
          pDataValues += 40;
        }
      }
    }

    /* FromWorkspace: '<S37>/FromWs' */
    {
      real_T *pDataValues = (real_T *) Team_6_DW.FromWs_PWORK_ej.DataPtr;
      real_T *pTimeValues = (real_T *) Team_6_DW.FromWs_PWORK_ej.TimePtr;
      int_T currTimeIndex = Team_6_DW.FromWs_IWORK_c.PrevIndex;
      real_T t = Team_6_M->Timing.t[0];

      /* Get index */
      if (t <= pTimeValues[0]) {
        currTimeIndex = 0;
      } else if (t >= pTimeValues[39]) {
        currTimeIndex = 38;
      } else {
        if (t < pTimeValues[currTimeIndex]) {
          while (t < pTimeValues[currTimeIndex]) {
            currTimeIndex--;
          }
        } else {
          while (t >= pTimeValues[currTimeIndex + 1]) {
            currTimeIndex++;
          }
        }
      }

      Team_6_DW.FromWs_IWORK_c.PrevIndex = currTimeIndex;

      /* Post output */
      {
        real_T t1 = pTimeValues[currTimeIndex];
        real_T t2 = pTimeValues[currTimeIndex + 1];
        if (t1 == t2) {
          if (t < t1) {
            Team_6_B.FromWs_j0 = pDataValues[currTimeIndex];
          } else {
            Team_6_B.FromWs_j0 = pDataValues[currTimeIndex + 1];
          }
        } else {
          real_T f1 = (t2 - t) / (t2 - t1);
          real_T f2 = 1.0 - f1;
          real_T d1;
          real_T d2;
          int_T TimeIndex= currTimeIndex;
          d1 = pDataValues[TimeIndex];
          d2 = pDataValues[TimeIndex + 1];
          Team_6_B.FromWs_j0 = (real_T) rtInterpolate(d1, d2, f1, f2);
          pDataValues += 40;
        }
      }
    }

    /* FromWorkspace: '<S36>/FromWs' */
    {
      real_T *pDataValues = (real_T *) Team_6_DW.FromWs_PWORK_dg.DataPtr;
      real_T *pTimeValues = (real_T *) Team_6_DW.FromWs_PWORK_dg.TimePtr;
      int_T currTimeIndex = Team_6_DW.FromWs_IWORK_dt.PrevIndex;
      real_T t = Team_6_M->Timing.t[0];

      /* Get index */
      if (t <= pTimeValues[0]) {
        currTimeIndex = 0;
      } else if (t >= pTimeValues[39]) {
        currTimeIndex = 38;
      } else {
        if (t < pTimeValues[currTimeIndex]) {
          while (t < pTimeValues[currTimeIndex]) {
            currTimeIndex--;
          }
        } else {
          while (t >= pTimeValues[currTimeIndex + 1]) {
            currTimeIndex++;
          }
        }
      }

      Team_6_DW.FromWs_IWORK_dt.PrevIndex = currTimeIndex;

      /* Post output */
      {
        real_T t1 = pTimeValues[currTimeIndex];
        real_T t2 = pTimeValues[currTimeIndex + 1];
        if (t1 == t2) {
          if (t < t1) {
            Team_6_B.FromWs_b = pDataValues[currTimeIndex];
          } else {
            Team_6_B.FromWs_b = pDataValues[currTimeIndex + 1];
          }
        } else {
          real_T f1 = (t2 - t) / (t2 - t1);
          real_T f2 = 1.0 - f1;
          real_T d1;
          real_T d2;
          int_T TimeIndex= currTimeIndex;
          d1 = pDataValues[TimeIndex];
          d2 = pDataValues[TimeIndex + 1];
          Team_6_B.FromWs_b = (real_T) rtInterpolate(d1, d2, f1, f2);
          pDataValues += 40;
        }
      }
    }

    /* If: '<S21>/If' incorporates:
     *  Constant: '<S21>/Constant1'
     *  Inport: '<S34>/In1'
     *  Inport: '<S35>/In1'
     */
    if (Team_6_B.FromWs[8] == 1.0) {
      rtAction = 0;

      /* Outputs for IfAction SubSystem: '<S21>/If Action Subsystem' incorporates:
       *  ActionPort: '<S32>/Action Port'
       */
      Team_6_IfActionSubsystem_m(Team_6_B.FromWs_b,
        &Team_6_B.IfActionSubsystem_j);

      /* End of Outputs for SubSystem: '<S21>/If Action Subsystem' */
    } else if (Team_6_B.FromWs[8] == 2.0) {
      rtAction = 1;

      /* Outputs for IfAction SubSystem: '<S21>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S33>/Action Port'
       */
      Team_6_IfActionSubsystem(Team_6_B.FromWs_j0,
        &Team_6_B.IfActionSubsystem1_i);

      /* End of Outputs for SubSystem: '<S21>/If Action Subsystem1' */
    } else if (Team_6_B.FromWs[8] == 3.0) {
      rtAction = 2;

      /* Outputs for IfAction SubSystem: '<S21>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S34>/Action Port'
       */
      Team_6_B.In1_h = Team_6_B.FromWs_jm;

      /* End of Outputs for SubSystem: '<S21>/If Action Subsystem2' */
    } else {
      rtAction = 3;

      /* Outputs for IfAction SubSystem: '<S21>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S35>/Action Port'
       */
      Team_6_B.In1 = Team_6_P.Constant1_Value_k;

      /* End of Outputs for SubSystem: '<S21>/If Action Subsystem3' */
    }

    Team_6_DW.If_ActiveSubsystem_g = rtAction;

    /* End of If: '<S21>/If' */
  }

  /* End of Outputs for SubSystem: '<S1>/HVAC' */
  /* Outputs for Atomic SubSystem: '<S1>/Seat_subsystem' */
  /* Outputs for Atomic SubSystem: '<S5>/Front_Right' */
  /* Outputs for Atomic SubSystem: '<S40>/Horizontal_Direction' */
  Team_6_Horizontal_Direction(Team_6_B.FromWs[10],
    &Team_6_B.Horizontal_Direction_m, &Team_6_DW.Horizontal_Direction_m,
    &Team_6_P.Horizontal_Direction_m);

  /* End of Outputs for SubSystem: '<S40>/Horizontal_Direction' */

  /* Outputs for Atomic SubSystem: '<S40>/Vertical_Direction' */
  /* If: '<S50>/check_user_input' incorporates:
   *  Constant: '<S50>/Cond_check'
   *  Constant: '<S50>/Cond_check1'
   *  Constant: '<S50>/Cond_check3'
   */
  if (Team_6_B.FromWs[10] == 1.0) {
    rtAction = 0;

    /* Outputs for IfAction SubSystem: '<S50>/If Action Subsystem' incorporates:
     *  ActionPort: '<S54>/Action Port'
     */
    Team_6_IfActionSubsystem(Team_6_P.Cond_check_Value_c,
      &Team_6_B.IfActionSubsystem_g);

    /* End of Outputs for SubSystem: '<S50>/If Action Subsystem' */
  } else if (Team_6_B.FromWs[10] == -1.0) {
    rtAction = 1;

    /* Outputs for IfAction SubSystem: '<S50>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S55>/Action Port'
     */
    Team_6_IfActionSubsystem(Team_6_P.Cond_check1_Value_j,
      &Team_6_B.IfActionSubsystem1_p);

    /* End of Outputs for SubSystem: '<S50>/If Action Subsystem1' */
  } else {
    rtAction = 2;

    /* Outputs for IfAction SubSystem: '<S50>/If Action Subsystem2' incorporates:
     *  ActionPort: '<S56>/Action Port'
     */
    Team_6_IfActionSubsystem(Team_6_P.Cond_check3_Value_h,
      &Team_6_B.IfActionSubsystem2_p3);

    /* End of Outputs for SubSystem: '<S50>/If Action Subsystem2' */
  }

  Team_6_DW.check_user_input_ActiveSubsyste = rtAction;

  /* End of If: '<S50>/check_user_input' */

  /* UnitDelay: '<S50>/Unit Delay' */
  Team_6_B.UnitDelay = Team_6_DW.UnitDelay_DSTATE;

  /* Sum: '<S50>/Add' */
  Team_6_B.Add = Team_6_B.IfActionSubsystem1_p.In1 + Team_6_B.UnitDelay;

  /* UnitDelay: '<S50>/Unit Delay1' */
  Team_6_B.UnitDelay1 = Team_6_DW.UnitDelay1_DSTATE;

  /* Sum: '<S50>/Add1' */
  Team_6_B.Add1 = Team_6_B.IfActionSubsystem_g.In1 + Team_6_B.UnitDelay1;

  /* End of Outputs for SubSystem: '<S40>/Vertical_Direction' */
  /* End of Outputs for SubSystem: '<S5>/Front_Right' */

  /* Outputs for Atomic SubSystem: '<S5>/Front_Left' */
  /* Outputs for Atomic SubSystem: '<S39>/Horizontal_Direction' */
  Team_6_Horizontal_Direction(Team_6_B.FromWs[11],
    &Team_6_B.Horizontal_Direction, &Team_6_DW.Horizontal_Direction,
    &Team_6_P.Horizontal_Direction);

  /* End of Outputs for SubSystem: '<S39>/Horizontal_Direction' */

  /* Outputs for Atomic SubSystem: '<S39>/Vertical_Direction' */
  /* If: '<S42>/check_user_input' incorporates:
   *  Constant: '<S42>/Cond_check'
   *  Constant: '<S42>/Cond_check1'
   *  Constant: '<S42>/Cond_check3'
   */
  if (Team_6_B.FromWs[11] == 1.0) {
    rtAction = 0;

    /* Outputs for IfAction SubSystem: '<S42>/If Action Subsystem' incorporates:
     *  ActionPort: '<S46>/Action Port'
     */
    Team_6_IfActionSubsystem(Team_6_P.Cond_check_Value,
      &Team_6_B.IfActionSubsystem_d);

    /* End of Outputs for SubSystem: '<S42>/If Action Subsystem' */
  } else if (Team_6_B.FromWs[11] == -1.0) {
    rtAction = 1;

    /* Outputs for IfAction SubSystem: '<S42>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S47>/Action Port'
     */
    Team_6_IfActionSubsystem(Team_6_P.Cond_check1_Value,
      &Team_6_B.IfActionSubsystem1_d);

    /* End of Outputs for SubSystem: '<S42>/If Action Subsystem1' */
  } else {
    rtAction = 2;

    /* Outputs for IfAction SubSystem: '<S42>/If Action Subsystem2' incorporates:
     *  ActionPort: '<S48>/Action Port'
     */
    Team_6_IfActionSubsystem(Team_6_P.Cond_check3_Value,
      &Team_6_B.IfActionSubsystem2_a);

    /* End of Outputs for SubSystem: '<S42>/If Action Subsystem2' */
  }

  Team_6_DW.check_user_input_ActiveSubsys_j = rtAction;

  /* End of If: '<S42>/check_user_input' */

  /* UnitDelay: '<S42>/Unit Delay' */
  Team_6_B.UnitDelay_a = Team_6_DW.UnitDelay_DSTATE_e;

  /* Sum: '<S42>/Add' */
  Team_6_B.Add_k = Team_6_B.IfActionSubsystem1_d.In1 + Team_6_B.UnitDelay_a;

  /* UnitDelay: '<S42>/Unit Delay1' */
  Team_6_B.UnitDelay1_g = Team_6_DW.UnitDelay1_DSTATE_p;

  /* Sum: '<S42>/Add1' */
  Team_6_B.Add1_b = Team_6_B.IfActionSubsystem_d.In1 + Team_6_B.UnitDelay1_g;

  /* End of Outputs for SubSystem: '<S39>/Vertical_Direction' */
  /* End of Outputs for SubSystem: '<S5>/Front_Left' */
  /* End of Outputs for SubSystem: '<S1>/Seat_subsystem' */
  /* Outputs for Atomic SubSystem: '<S1>/Wiper Subsystem' */
  /* Gain: '<S57>/Input Gain' */
  Team_6_B.InputGain = Team_6_P.InputGain_Gain * Team_6_B.FromWs[5];

  /* SignalGenerator: '<S57>/Signal Generator2' */
  Team_6_B.SignalGenerator2 = sin(Team_6_P.SignalGenerator2_Frequency *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator2_Amplitude;

  /* SignalGenerator: '<S57>/Signal Generator1' */
  Team_6_B.SignalGenerator1 = sin(Team_6_P.SignalGenerator1_Frequency *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator1_Amplitude;

  /* SignalGenerator: '<S57>/Signal Generator' */
  Team_6_B.SignalGenerator = sin(Team_6_P.SignalGenerator_Frequency *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator_Amplitude;

  /* SignalGenerator: '<S57>/Signal Generator3' */
  Team_6_B.SignalGenerator3 = sin(Team_6_P.SignalGenerator3_Frequency *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator3_Amplitude;

  /* If: '<S57>/if else block' */
  if (Team_6_B.InputGain <= 20.0) {
    rtAction = 0;

    /* Outputs for IfAction SubSystem: '<S57>/If Action Subsystem' incorporates:
     *  ActionPort: '<S59>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator3,
      &Team_6_B.mergingthedata);

    /* End of Outputs for SubSystem: '<S57>/If Action Subsystem' */
  } else if (Team_6_B.InputGain <= 40.0) {
    rtAction = 1;

    /* Outputs for IfAction SubSystem: '<S57>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S60>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator,
      &Team_6_B.mergingthedata);

    /* End of Outputs for SubSystem: '<S57>/If Action Subsystem1' */
  } else if (Team_6_B.InputGain <= 60.0) {
    rtAction = 2;

    /* Outputs for IfAction SubSystem: '<S57>/If Action Subsystem2' incorporates:
     *  ActionPort: '<S61>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator1,
      &Team_6_B.mergingthedata);

    /* End of Outputs for SubSystem: '<S57>/If Action Subsystem2' */
  } else {
    rtAction = 3;

    /* Outputs for IfAction SubSystem: '<S57>/If Action Subsystem3' incorporates:
     *  ActionPort: '<S62>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator2,
      &Team_6_B.mergingthedata);

    /* End of Outputs for SubSystem: '<S57>/If Action Subsystem3' */
  }

  Team_6_DW.ifelseblock_ActiveSubsystem = rtAction;

  /* End of If: '<S57>/if else block' */

  /* Gain: '<S58>/Input Gain' */
  Team_6_B.InputGain_f = Team_6_P.InputGain_Gain_h * Team_6_B.FromWs[5];

  /* SignalGenerator: '<S58>/Signal Generator2' */
  Team_6_B.SignalGenerator2_m = sin(Team_6_P.SignalGenerator2_Frequency_a *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator2_Amplitude_p;

  /* SignalGenerator: '<S58>/Signal Generator1' */
  Team_6_B.SignalGenerator1_o = sin(Team_6_P.SignalGenerator1_Frequency_g *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator1_Amplitude_g;

  /* SignalGenerator: '<S58>/Signal Generator' */
  Team_6_B.SignalGenerator_k = sin(Team_6_P.SignalGenerator_Frequency_d *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator_Amplitude_e;

  /* SignalGenerator: '<S58>/Signal Generator3' */
  Team_6_B.SignalGenerator3_m = sin(Team_6_P.SignalGenerator3_Frequency_i *
    Team_6_M->Timing.t[0]) * Team_6_P.SignalGenerator3_Amplitude_k;

  /* If: '<S58>/if else block' */
  if (Team_6_B.InputGain_f <= 20.0) {
    rtAction = 0;

    /* Outputs for IfAction SubSystem: '<S58>/If Action Subsystem' incorporates:
     *  ActionPort: '<S63>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator3_m,
      &Team_6_B.mergingthedata_e);

    /* End of Outputs for SubSystem: '<S58>/If Action Subsystem' */
  } else if (Team_6_B.InputGain_f <= 40.0) {
    rtAction = 1;

    /* Outputs for IfAction SubSystem: '<S58>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S64>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator_k,
      &Team_6_B.mergingthedata_e);

    /* End of Outputs for SubSystem: '<S58>/If Action Subsystem1' */
  } else if (Team_6_B.InputGain_f <= 60.0) {
    rtAction = 2;

    /* Outputs for IfAction SubSystem: '<S58>/If Action Subsystem2' incorporates:
     *  ActionPort: '<S65>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator1_o,
      &Team_6_B.mergingthedata_e);

    /* End of Outputs for SubSystem: '<S58>/If Action Subsystem2' */
  } else {
    rtAction = 3;

    /* Outputs for IfAction SubSystem: '<S58>/If Action Subsystem3' incorporates:
     *  ActionPort: '<S66>/Action Port'
     */
    Team_6_IfActionSubsystem_e(Team_6_B.SignalGenerator2_m,
      &Team_6_B.mergingthedata_e);

    /* End of Outputs for SubSystem: '<S58>/If Action Subsystem3' */
  }

  Team_6_DW.ifelseblock_ActiveSubsystem_n = rtAction;

  /* End of If: '<S58>/if else block' */
  /* End of Outputs for SubSystem: '<S1>/Wiper Subsystem' */
  /* Logic: '<S1>/lock' */
  Team_6_B.lock_control = !(Team_6_B.FromWs[16] != 0.0);

  /* SignalConversion generated from: '<S8>/Enable' */
  Team_6_B.HiddenBuf_InsertedFor_power_win = Team_6_B.lock_control;

  /* Outputs for Enabled SubSystem: '<S1>/power_window' incorporates:
   *  EnablePort: '<S8>/Enable'
   */
  if (Team_6_B.HiddenBuf_InsertedFor_power_win) {
    Team_6_DW.power_window_MODE = true;
  } else {
    if (Team_6_DW.power_window_MODE) {
      /* Disable for Enabled SubSystem: '<S8>/Back_left_passenger' */
      if (Team_6_DW.Back_left_passenger.Back_left_passenger_MODE) {
        Tea_Back_left_passenger_Disable(&Team_6_DW.Back_left_passenger);
      }

      /* End of Disable for SubSystem: '<S8>/Back_left_passenger' */

      /* Disable for Enabled SubSystem: '<S8>/Back_right_passenger' */
      if (Team_6_DW.Back_right_passenger.Back_left_passenger_MODE) {
        Tea_Back_left_passenger_Disable(&Team_6_DW.Back_right_passenger);
      }

      /* End of Disable for SubSystem: '<S8>/Back_right_passenger' */

      /* Disable for SwitchCase: '<S79>/Window States' */
      Team_6_DW.WindowStates_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S8>/front_passenger' */
      if (Team_6_DW.front_passenger.Back_left_passenger_MODE) {
        Tea_Back_left_passenger_Disable(&Team_6_DW.front_passenger);
      }

      /* End of Disable for SubSystem: '<S8>/front_passenger' */
      Team_6_DW.power_window_MODE = false;
    }
  }

  if (Team_6_DW.power_window_MODE) {
    /* Logic: '<S8>/Driver_priority' */
    Team_6_B.Driver_priority = !(Team_6_B.FromWs[17] != 0.0);

    /* SignalConversion generated from: '<S77>/Enable' */
    Team_6_B.HiddenBuf_InsertedFor_Back_left = Team_6_B.Driver_priority;

    /* Outputs for Enabled SubSystem: '<S8>/Back_left_passenger' */
    Team_6_Back_left_passenger(Team_6_B.HiddenBuf_InsertedFor_Back_left,
      Team_6_B.FromWs[19], &Team_6_B.Back_left_passenger,
      &Team_6_DW.Back_left_passenger, &Team_6_P.Back_left_passenger);

    /* End of Outputs for SubSystem: '<S8>/Back_left_passenger' */

    /* SignalConversion generated from: '<S78>/Enable' */
    Team_6_B.HiddenBuf_InsertedFor_Back_righ = Team_6_B.Driver_priority;

    /* Outputs for Enabled SubSystem: '<S8>/Back_right_passenger' */
    Team_6_Back_left_passenger(Team_6_B.HiddenBuf_InsertedFor_Back_righ,
      Team_6_B.FromWs[20], &Team_6_B.Back_right_passenger,
      &Team_6_DW.Back_right_passenger, &Team_6_P.Back_right_passenger);

    /* End of Outputs for SubSystem: '<S8>/Back_right_passenger' */

    /* SignalConversion generated from: '<S80>/Enable' */
    Team_6_B.HiddenBuf_InsertedFor_front_pas = Team_6_B.Driver_priority;

    /* SwitchCase: '<S79>/Window States' incorporates:
     *  Constant: '<S79>/Long_Down_ip'
     *  Constant: '<S79>/Long_Up_ip'
     *  Constant: '<S79>/Short_Down_ip'
     *  Constant: '<S79>/Short_Up_ip'
     *  Constant: '<S79>/default'
     */
    tmp = trunc(Team_6_B.FromWs[17]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = fmod(tmp, 4.294967296E+9);
    }

    switch (tmp < 0.0 ? -(int32_T)(uint32_T)-tmp : (int32_T)(uint32_T)tmp) {
     case 1:
      rtAction = 0;
      break;

     case 2:
      rtAction = 1;
      break;

     case 3:
      rtAction = 2;
      break;

     case 4:
      rtAction = 3;
      break;

     default:
      rtAction = 4;
      break;
    }

    Team_6_DW.WindowStates_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S79>/Long_Up' incorporates:
       *  ActionPort: '<S93>/Action Port'
       */
      Team_6_IfActionSubsystem_e(Team_6_P.Long_Up_ip_Value, &Team_6_B.Merge);

      /* End of Outputs for SubSystem: '<S79>/Long_Up' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S79>/Short_Up' incorporates:
       *  ActionPort: '<S95>/Action Port'
       */
      Team_6_IfActionSubsystem_e(Team_6_P.Short_Up_ip_Value, &Team_6_B.Merge);

      /* End of Outputs for SubSystem: '<S79>/Short_Up' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S79>/Short_Down' incorporates:
       *  ActionPort: '<S94>/Action Port'
       */
      Team_6_IfActionSubsystem_e(Team_6_P.Short_Down_ip_Value, &Team_6_B.Merge);

      /* End of Outputs for SubSystem: '<S79>/Short_Down' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S79>/Long_Down' incorporates:
       *  ActionPort: '<S92>/Action Port'
       */
      Team_6_IfActionSubsystem_e(Team_6_P.Long_Down_ip_Value, &Team_6_B.Merge);

      /* End of Outputs for SubSystem: '<S79>/Long_Down' */
      break;

     default:
      /* Outputs for IfAction SubSystem: '<S79>/Do_Nothing' incorporates:
       *  ActionPort: '<S91>/Action Port'
       */
      Team_6_IfActionSubsystem_e(Team_6_P.default_Value, &Team_6_B.Merge);

      /* End of Outputs for SubSystem: '<S79>/Do_Nothing' */
      break;
    }

    /* End of SwitchCase: '<S79>/Window States' */

    /* Outputs for Enabled SubSystem: '<S8>/front_passenger' */
    Team_6_Back_left_passenger(Team_6_B.HiddenBuf_InsertedFor_front_pas,
      Team_6_B.FromWs[18], &Team_6_B.front_passenger, &Team_6_DW.front_passenger,
      &Team_6_P.front_passenger);

    /* End of Outputs for SubSystem: '<S8>/front_passenger' */
  }

  /* End of Outputs for SubSystem: '<S1>/power_window' */
  /* Outputs for Atomic SubSystem: '<S1>/External Light' */
  /* DiscretePulseGenerator: '<S10>/Continuous Pulse Generator' */
  Team_6_B.ContinuousPulseGenerator = (Team_6_DW.clockTickCounter <
    Team_6_P.ContinuousPulseGenerator_Duty) && (Team_6_DW.clockTickCounter >= 0)
    ? Team_6_P.ContinuousPulseGenerator_Amp : 0.0;

  /* DiscretePulseGenerator: '<S10>/Continuous Pulse Generator' */
  if (Team_6_DW.clockTickCounter >= Team_6_P.ContinuousPulseGenerator_Period -
      1.0) {
    Team_6_DW.clockTickCounter = 0;
  } else {
    Team_6_DW.clockTickCounter++;
  }

  /* Logic: '<S10>/AND' */
  Team_6_B.AND = ((Team_6_B.ContinuousPulseGenerator != 0.0) &&
                  (Team_6_B.FromWs[1] != 0.0));

  /* Outputs for Triggered SubSystem: '<S10>/Triggered Subsystem' incorporates:
   *  TriggerPort: '<S17>/Trigger'
   */
  zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,
                     &Team_6_PrevZCX.TriggeredSubsystem_Trig_ZCE,
                     (Team_6_B.ContinuousPulseGenerator));
  if (zcEvent != NO_ZCEVENT) {
    /* Inport: '<S17>/In1' */
    Team_6_B.In1_i = Team_6_B.AND;
  }

  /* End of Outputs for SubSystem: '<S10>/Triggered Subsystem' */
  /* If: '<S3>/If' */
  rtAction = -1;
  if (Team_6_B.FromWs[3] == 1.0) {
    rtAction = 0;

    /* Outputs for IfAction SubSystem: '<S3>/If Action Subsystem' incorporates:
     *  ActionPort: '<S11>/Action Port'
     */
    Team_6_IfActionSubsystem(Team_6_B.FromWs[4], &Team_6_B.IfActionSubsystem);

    /* End of Outputs for SubSystem: '<S3>/If Action Subsystem' */
  }

  Team_6_DW.If_ActiveSubsystem_f = rtAction;

  /* End of If: '<S3>/If' */
  /* End of Outputs for SubSystem: '<S1>/External Light' */

  /* Outputs for Atomic SubSystem: '<S1>/mirror' */
  /* SignalConversion generated from: '<S68>/Enable' */
  Team_6_B.HiddenBuf_InsertedFor_right_mir = Team_6_B.FromWs[12];

  /* Outputs for Enabled SubSystem: '<S7>/right_mirror' */
  Team_6_left_mirror(Team_6_B.HiddenBuf_InsertedFor_right_mir, Team_6_B.FromWs
                     [13], &Team_6_B.right_mirror, &Team_6_DW.right_mirror,
                     &Team_6_P.right_mirror);

  /* End of Outputs for SubSystem: '<S7>/right_mirror' */

  /* SignalConversion generated from: '<S67>/Enable' */
  Team_6_B.HiddenBuf_InsertedFor_left_mirr = Team_6_B.FromWs[14];

  /* Outputs for Enabled SubSystem: '<S7>/left_mirror' */
  Team_6_left_mirror(Team_6_B.HiddenBuf_InsertedFor_left_mirr, Team_6_B.FromWs
                     [15], &Team_6_B.left_mirror, &Team_6_DW.left_mirror,
                     &Team_6_P.left_mirror);

  /* End of Outputs for SubSystem: '<S7>/left_mirror' */
  /* End of Outputs for SubSystem: '<S1>/mirror' */

  /* Matfile logging */
  rt_UpdateTXYLogVars(Team_6_M->rtwLogInfo, (Team_6_M->Timing.t));

  /* Update for Atomic SubSystem: '<S1>/Seat_subsystem' */
  /* Update for Atomic SubSystem: '<S5>/Front_Right' */
  /* Update for Atomic SubSystem: '<S40>/Horizontal_Direction' */
  Tea_Horizontal_Direction_Update(&Team_6_B.Horizontal_Direction_m,
    &Team_6_DW.Horizontal_Direction_m);

  /* End of Update for SubSystem: '<S40>/Horizontal_Direction' */

  /* Update for Atomic SubSystem: '<S40>/Vertical_Direction' */
  /* Update for UnitDelay: '<S50>/Unit Delay' */
  Team_6_DW.UnitDelay_DSTATE = Team_6_B.Add;

  /* Update for UnitDelay: '<S50>/Unit Delay1' */
  Team_6_DW.UnitDelay1_DSTATE = Team_6_B.Add1;

  /* End of Update for SubSystem: '<S40>/Vertical_Direction' */
  /* End of Update for SubSystem: '<S5>/Front_Right' */

  /* Update for Atomic SubSystem: '<S5>/Front_Left' */
  /* Update for Atomic SubSystem: '<S39>/Horizontal_Direction' */
  Tea_Horizontal_Direction_Update(&Team_6_B.Horizontal_Direction,
    &Team_6_DW.Horizontal_Direction);

  /* End of Update for SubSystem: '<S39>/Horizontal_Direction' */

  /* Update for Atomic SubSystem: '<S39>/Vertical_Direction' */
  /* Update for UnitDelay: '<S42>/Unit Delay' */
  Team_6_DW.UnitDelay_DSTATE_e = Team_6_B.Add_k;

  /* Update for UnitDelay: '<S42>/Unit Delay1' */
  Team_6_DW.UnitDelay1_DSTATE_p = Team_6_B.Add1_b;

  /* End of Update for SubSystem: '<S39>/Vertical_Direction' */
  /* End of Update for SubSystem: '<S5>/Front_Left' */
  /* End of Update for SubSystem: '<S1>/Seat_subsystem' */

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(Team_6_M)!=-1) &&
        !((rtmGetTFinal(Team_6_M)-Team_6_M->Timing.t[0]) > Team_6_M->Timing.t[0]
          * (DBL_EPSILON))) {
      rtmSetErrorStatus(Team_6_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Team_6_M->Timing.clockTick0)) {
    ++Team_6_M->Timing.clockTickH0;
  }

  Team_6_M->Timing.t[0] = Team_6_M->Timing.clockTick0 *
    Team_6_M->Timing.stepSize0 + Team_6_M->Timing.clockTickH0 *
    Team_6_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.5s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.5, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    Team_6_M->Timing.clockTick1++;
    if (!Team_6_M->Timing.clockTick1) {
      Team_6_M->Timing.clockTickH1++;
    }
  }
}

/* Model initialize function */
void Team_6_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Team_6_M, 0,
                sizeof(RT_MODEL_Team_6_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Team_6_M->solverInfo, &Team_6_M->Timing.simTimeStep);
    rtsiSetTPtr(&Team_6_M->solverInfo, &rtmGetTPtr(Team_6_M));
    rtsiSetStepSizePtr(&Team_6_M->solverInfo, &Team_6_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&Team_6_M->solverInfo, (&rtmGetErrorStatus(Team_6_M)));
    rtsiSetRTModelPtr(&Team_6_M->solverInfo, Team_6_M);
  }

  rtsiSetSimTimeStep(&Team_6_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&Team_6_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(Team_6_M, &Team_6_M->Timing.tArray[0]);
  rtmSetTFinal(Team_6_M, 10.0);
  Team_6_M->Timing.stepSize0 = 0.5;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Team_6_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Team_6_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Team_6_M->rtwLogInfo, (NULL));
    rtliSetLogT(Team_6_M->rtwLogInfo, "tout");
    rtliSetLogX(Team_6_M->rtwLogInfo, "");
    rtliSetLogXFinal(Team_6_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Team_6_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Team_6_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(Team_6_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Team_6_M->rtwLogInfo, 1);
    rtliSetLogY(Team_6_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Team_6_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Team_6_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &Team_6_B), 0,
                sizeof(B_Team_6_T));

  /* states (dwork) */
  (void) memset((void *)&Team_6_DW, 0,
                sizeof(DW_Team_6_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Team_6_M->rtwLogInfo, 0.0, rtmGetTFinal
    (Team_6_M), Team_6_M->Timing.stepSize0, (&rtmGetErrorStatus(Team_6_M)));

  /* Start for FromWorkspace: '<S2>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.5, 0.5, 1.0, 1.0, 1.5, 1.5, 2.0, 2.0,
      2.5, 2.5, 3.0, 3.0, 3.5, 3.5, 4.0, 4.0, 4.0200000000000005,
      4.0200000000000005, 4.5, 4.5, 5.0, 5.0, 5.5, 5.5, 5.96, 5.96, 6.0, 6.0,
      6.5, 6.5, 7.0, 7.0, 7.5, 7.5, 7.96, 7.96, 8.0, 8.0, 8.5, 8.5, 9.0, 9.0,
      9.5, 9.5, 10.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 2.0, 2.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.05, 1.05,
      1.05, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.05, 1.05, 1.05, 1.05, 1.05,
      1.05, 1.05, 1.05, 1.05, 1.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4,
      -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4,
      -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4,
      -0.4, -0.4, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 3.0, 3.0, 3.0, 3.0,
      2.5, 1.0, 2.0, 2.0, 0.85000000000000009, 0.85000000000000009,
      1.9500000000000002, 1.9500000000000002, 1.0, 1.0, 1.1, 1.1, 2.0, 2.0, 2.0,
      2.0, 0.95000000000000007, 0.95000000000000007, 0.8, 0.8,
      0.95000000000000007, 0.95000000000000007, 0.95000000000000007,
      0.95000000000000007, 2.0, 2.0, 0.8, 0.8, 2.5, 2.5, 2.0500000000000003,
      2.0500000000000003, 2.0500000000000003, 2.0500000000000003,
      0.95000000000000007, 0.95000000000000007, 0.60000000000000009,
      0.60000000000000009, 0.0, 0.0, 5.0, 5.0, 2.0, 2.0, 1.0, 1.0, 0.0, 0.0, 0.9,
      0.9, 2.0, 2.0, 3.0, 3.0, 1.2000000000000002, 1.2000000000000002, 2.2, 2.2,
      0.9, 0.9, 0.9, 0.9, 0.0, 0.0, 2.0, 2.0, 3.0, 3.0, 3.0, 3.0, 2.0, 2.0, 0.0,
      0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 2.0, 2.0,
      2.0, 2.0, 0.9, 0.9, 0.0, 0.0, 0.8, 0.8, 2.0, 2.0, 0.0, 0.0, 3.0, 3.0, 1.0,
      1.0, 2.0, 2.0, 2.0, 2.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 3.0, 3.0,
      2.0, 2.0, 3.0, 3.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 1.0,
      1.0, 2.0, 2.0, 1.1, 1.1, 0.0, 0.0, 1.8, 1.8, 0.9, 0.9, 1.9000000000000001,
      1.9000000000000001, 0.1, 0.1, 1.8, 1.8, -0.2, -0.2, -0.2, -0.2,
      1.4000000000000001, 1.4000000000000001, 3.0, 3.0, 0.0, 0.0, 0.0, 0.0, 2.0,
      2.0, 3.0, 3.0, 2.0, 2.0, 1.0, 1.0, 1.0, 1.0, 2.0, 2.0, 0.0, 0.0, 3.0, 3.0,
      1.1, 1.1, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 0.0,
      0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0, 2.0, 2.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, -1.0, -1.0, 0.0, 0.0, 1.0,
      1.0, 0.0, 0.0, -1.0, -1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, -1.0, -1.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, -1.0, -1.0, -1.0, -1.0,
      0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      -1.0, -1.0, 1.0, 1.0, 2.0, 2.0, -0.0, -0.0, 1.0, 1.0, -1.0, -1.0, 2.0, 2.0,
      2.0, 2.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 2.0, 2.0, 1.0, 1.0,
      2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, -1.0, -1.0, 1.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      1.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0,
      0.0, 0.0, 2.0, 2.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
      1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0,
      4.0, 4.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0,
      0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 3.0, 3.0, 0.0,
      0.0, 4.0, 4.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0, 2.0, 2.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 3.0, 3.0,
      0.0, 0.0, 4.0, 4.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0,
      0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 3.0,
      3.0, 0.0, 0.0, 4.0, 4.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0,
      0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0 } ;

    Team_6_DW.FromWs_PWORK.TimePtr = (void *) pTimeValues0;
    Team_6_DW.FromWs_PWORK.DataPtr = (void *) pDataValues0;
    Team_6_DW.FromWs_IWORK.PrevIndex = 0;
  }

  Team_6_PrevZCX.TriggeredSubsystem_Trig_ZCE = UNINITIALIZED_ZCSIG;

  /* SystemInitialize for Enabled SubSystem: '<S1>/HVAC' */
  /* Start for If: '<S19>/If' */
  Team_6_DW.If_ActiveSubsystem = -1;

  /* Start for FromWorkspace: '<S31>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.75, 0.75, 1.0, 1.0, 1.75, 1.75, 2.0,
      2.0, 2.75, 2.75, 3.0, 3.0, 3.75, 3.75, 4.0, 4.0, 4.75, 4.75, 5.0, 5.0,
      5.75, 5.75, 6.0, 6.0, 6.75, 6.75, 7.0, 7.0, 7.75, 7.75, 8.0, 8.0, 8.75,
      8.75, 9.0, 9.0, 9.75, 9.75, 10.0 } ;

    static real_T pDataValues0[] = { 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0 } ;

    Team_6_DW.FromWs_PWORK_e.TimePtr = (void *) pTimeValues0;
    Team_6_DW.FromWs_PWORK_e.DataPtr = (void *) pDataValues0;
    Team_6_DW.FromWs_IWORK_d.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<S30>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.5, 0.5, 1.0, 1.0, 1.5, 1.5, 2.0, 2.0,
      2.5, 2.5, 3.0, 3.0, 3.5, 3.5, 4.0, 4.0, 4.5, 4.5, 5.0, 5.0, 5.5, 5.5, 6.0,
      6.0, 6.5, 6.5, 7.0, 7.0, 7.5, 7.5, 8.0, 8.0, 8.5, 8.5, 9.0, 9.0, 9.5, 9.5,
      10.0 } ;

    static real_T pDataValues0[] = { 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0 } ;

    Team_6_DW.FromWs_PWORK_n.TimePtr = (void *) pTimeValues0;
    Team_6_DW.FromWs_PWORK_n.DataPtr = (void *) pDataValues0;
    Team_6_DW.FromWs_IWORK_f.PrevIndex = 0;
  }

  /* Start for If: '<S20>/If' */
  Team_6_DW.If_ActiveSubsystem_o = -1;

  /* Start for FromWorkspace: '<S38>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.75, 0.75, 1.0, 1.0, 1.75, 1.75, 2.0,
      2.0, 2.75, 2.75, 3.0, 3.0, 3.75, 3.75, 4.0, 4.0, 4.75, 4.75, 5.0, 5.0,
      5.75, 5.75, 6.0, 6.0, 6.75, 6.75, 7.0, 7.0, 7.75, 7.75, 8.0, 8.0, 8.75,
      8.75, 9.0, 9.0, 9.75, 9.75, 10.0 } ;

    static real_T pDataValues0[] = { 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0 } ;

    Team_6_DW.FromWs_PWORK_d.TimePtr = (void *) pTimeValues0;
    Team_6_DW.FromWs_PWORK_d.DataPtr = (void *) pDataValues0;
    Team_6_DW.FromWs_IWORK_n.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<S37>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.5, 0.5, 1.0, 1.0, 1.5, 1.5, 2.0, 2.0,
      2.5, 2.5, 3.0, 3.0, 3.5, 3.5, 4.0, 4.0, 4.5, 4.5, 5.0, 5.0, 5.5, 5.5, 6.0,
      6.0, 6.5, 6.5, 7.0, 7.0, 7.5, 7.5, 8.0, 8.0, 8.5, 8.5, 9.0, 9.0, 9.5, 9.5,
      10.0 } ;

    static real_T pDataValues0[] = { 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0 } ;

    Team_6_DW.FromWs_PWORK_ej.TimePtr = (void *) pTimeValues0;
    Team_6_DW.FromWs_PWORK_ej.DataPtr = (void *) pDataValues0;
    Team_6_DW.FromWs_IWORK_c.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<S36>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.25, 0.25, 1.0, 1.0, 1.25, 1.25, 2.0,
      2.0, 2.25, 2.25, 3.0, 3.0, 3.25, 3.25, 4.0, 4.0, 4.25, 4.25, 5.0, 5.0,
      5.25, 5.25, 6.0, 6.0, 6.25, 6.25, 7.0, 7.0, 7.25, 7.25, 8.0, 8.0, 8.25,
      8.25, 9.0, 9.0, 9.25, 9.25, 10.0 } ;

    static real_T pDataValues0[] = { 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0,
      2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0,
      2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 2.0, 2.0, 0.0,
      0.0 } ;

    Team_6_DW.FromWs_PWORK_dg.TimePtr = (void *) pTimeValues0;
    Team_6_DW.FromWs_PWORK_dg.DataPtr = (void *) pDataValues0;
    Team_6_DW.FromWs_IWORK_dt.PrevIndex = 0;
  }

  /* Start for If: '<S21>/If' */
  Team_6_DW.If_ActiveSubsystem_g = -1;

  /* SystemInitialize for IfAction SubSystem: '<S19>/If Action Subsystem' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem_b,
    &Team_6_P.IfActionSubsystem_b);

  /* End of SystemInitialize for SubSystem: '<S19>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S19>/If Action Subsystem1' */
  /* SystemInitialize for Outport: '<S23>/Output1' incorporates:
   *  Inport: '<S23>/In1'
   */
  Team_6_B.In1_j = Team_6_P.Output1_Y0;

  /* End of SystemInitialize for SubSystem: '<S19>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S19>/If Action Subsystem2' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem2,
    &Team_6_P.IfActionSubsystem2);

  /* End of SystemInitialize for SubSystem: '<S19>/If Action Subsystem2' */

  /* SystemInitialize for IfAction SubSystem: '<S19>/If Action Subsystem3' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem3,
    &Team_6_P.IfActionSubsystem3);

  /* End of SystemInitialize for SubSystem: '<S19>/If Action Subsystem3' */

  /* SystemInitialize for IfAction SubSystem: '<S20>/If Action Subsystem' */
  Team_6_IfActionSubsystem_f_Init(&Team_6_B.IfActionSubsystem_m,
    &Team_6_P.IfActionSubsystem_m);

  /* End of SystemInitialize for SubSystem: '<S20>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S20>/If Action Subsystem1' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem1_n,
    &Team_6_P.IfActionSubsystem1_n);

  /* End of SystemInitialize for SubSystem: '<S20>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S20>/If Action Subsystem2' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem2_p,
    &Team_6_P.IfActionSubsystem2_p);

  /* End of SystemInitialize for SubSystem: '<S20>/If Action Subsystem2' */

  /* SystemInitialize for IfAction SubSystem: '<S20>/If Action Subsystem3' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem3_d,
    &Team_6_P.IfActionSubsystem3_d);

  /* End of SystemInitialize for SubSystem: '<S20>/If Action Subsystem3' */

  /* SystemInitialize for IfAction SubSystem: '<S21>/If Action Subsystem' */
  Team_6_IfActionSubsystem_f_Init(&Team_6_B.IfActionSubsystem_j,
    &Team_6_P.IfActionSubsystem_j);

  /* End of SystemInitialize for SubSystem: '<S21>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S21>/If Action Subsystem1' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem1_i,
    &Team_6_P.IfActionSubsystem1_i);

  /* End of SystemInitialize for SubSystem: '<S21>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S21>/If Action Subsystem2' */
  /* SystemInitialize for Outport: '<S34>/Output2' incorporates:
   *  Inport: '<S34>/In1'
   */
  Team_6_B.In1_h = Team_6_P.Output2_Y0;

  /* End of SystemInitialize for SubSystem: '<S21>/If Action Subsystem2' */

  /* SystemInitialize for IfAction SubSystem: '<S21>/If Action Subsystem3' */
  /* SystemInitialize for Outport: '<S35>/Output3' incorporates:
   *  Inport: '<S35>/In1'
   */
  Team_6_B.In1 = Team_6_P.Output3_Y0;

  /* End of SystemInitialize for SubSystem: '<S21>/If Action Subsystem3' */
  /* End of SystemInitialize for SubSystem: '<S1>/HVAC' */

  /* SystemInitialize for Atomic SubSystem: '<S1>/Seat_subsystem' */
  /* SystemInitialize for Atomic SubSystem: '<S5>/Front_Right' */
  /* SystemInitialize for Atomic SubSystem: '<S40>/Horizontal_Direction' */
  Team__Horizontal_Direction_Init(&Team_6_B.Horizontal_Direction_m,
    &Team_6_DW.Horizontal_Direction_m, &Team_6_P.Horizontal_Direction_m);

  /* End of SystemInitialize for SubSystem: '<S40>/Horizontal_Direction' */

  /* SystemInitialize for Atomic SubSystem: '<S40>/Vertical_Direction' */
  /* Start for If: '<S50>/check_user_input' */
  Team_6_DW.check_user_input_ActiveSubsyste = -1;

  /* InitializeConditions for UnitDelay: '<S50>/Unit Delay' */
  Team_6_DW.UnitDelay_DSTATE = Team_6_P.UnitDelay_InitialCondition_p;

  /* InitializeConditions for UnitDelay: '<S50>/Unit Delay1' */
  Team_6_DW.UnitDelay1_DSTATE = Team_6_P.UnitDelay1_InitialCondition_g;

  /* SystemInitialize for IfAction SubSystem: '<S50>/If Action Subsystem' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem_g,
    &Team_6_P.IfActionSubsystem_g);

  /* End of SystemInitialize for SubSystem: '<S50>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S50>/If Action Subsystem1' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem1_p,
    &Team_6_P.IfActionSubsystem1_p);

  /* End of SystemInitialize for SubSystem: '<S50>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S50>/If Action Subsystem2' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem2_p3,
    &Team_6_P.IfActionSubsystem2_p3);

  /* End of SystemInitialize for SubSystem: '<S50>/If Action Subsystem2' */
  /* End of SystemInitialize for SubSystem: '<S40>/Vertical_Direction' */
  /* End of SystemInitialize for SubSystem: '<S5>/Front_Right' */

  /* SystemInitialize for Atomic SubSystem: '<S5>/Front_Left' */
  /* SystemInitialize for Atomic SubSystem: '<S39>/Horizontal_Direction' */
  Team__Horizontal_Direction_Init(&Team_6_B.Horizontal_Direction,
    &Team_6_DW.Horizontal_Direction, &Team_6_P.Horizontal_Direction);

  /* End of SystemInitialize for SubSystem: '<S39>/Horizontal_Direction' */

  /* SystemInitialize for Atomic SubSystem: '<S39>/Vertical_Direction' */
  /* Start for If: '<S42>/check_user_input' */
  Team_6_DW.check_user_input_ActiveSubsys_j = -1;

  /* InitializeConditions for UnitDelay: '<S42>/Unit Delay' */
  Team_6_DW.UnitDelay_DSTATE_e = Team_6_P.UnitDelay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S42>/Unit Delay1' */
  Team_6_DW.UnitDelay1_DSTATE_p = Team_6_P.UnitDelay1_InitialCondition;

  /* SystemInitialize for IfAction SubSystem: '<S42>/If Action Subsystem' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem_d,
    &Team_6_P.IfActionSubsystem_d);

  /* End of SystemInitialize for SubSystem: '<S42>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S42>/If Action Subsystem1' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem1_d,
    &Team_6_P.IfActionSubsystem1_d);

  /* End of SystemInitialize for SubSystem: '<S42>/If Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S42>/If Action Subsystem2' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem2_a,
    &Team_6_P.IfActionSubsystem2_a);

  /* End of SystemInitialize for SubSystem: '<S42>/If Action Subsystem2' */
  /* End of SystemInitialize for SubSystem: '<S39>/Vertical_Direction' */
  /* End of SystemInitialize for SubSystem: '<S5>/Front_Left' */
  /* End of SystemInitialize for SubSystem: '<S1>/Seat_subsystem' */

  /* SystemInitialize for Atomic SubSystem: '<S1>/Wiper Subsystem' */
  /* Start for If: '<S57>/if else block' */
  Team_6_DW.ifelseblock_ActiveSubsystem = -1;

  /* Start for If: '<S58>/if else block' */
  Team_6_DW.ifelseblock_ActiveSubsystem_n = -1;

  /* End of SystemInitialize for SubSystem: '<S1>/Wiper Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S1>/power_window' */
  /* Start for SwitchCase: '<S79>/Window States' */
  Team_6_DW.WindowStates_ActiveSubsystem = -1;

  /* SystemInitialize for Enabled SubSystem: '<S8>/Back_left_passenger' */
  Team_6_Back_left_passenger_Init(&Team_6_B.Back_left_passenger,
    &Team_6_DW.Back_left_passenger, &Team_6_P.Back_left_passenger);

  /* End of SystemInitialize for SubSystem: '<S8>/Back_left_passenger' */

  /* SystemInitialize for Enabled SubSystem: '<S8>/Back_right_passenger' */
  Team_6_Back_left_passenger_Init(&Team_6_B.Back_right_passenger,
    &Team_6_DW.Back_right_passenger, &Team_6_P.Back_right_passenger);

  /* End of SystemInitialize for SubSystem: '<S8>/Back_right_passenger' */

  /* SystemInitialize for Merge: '<S79>/Merge' */
  Team_6_B.Merge = Team_6_P.Merge_InitialOutput;

  /* SystemInitialize for Enabled SubSystem: '<S8>/front_passenger' */
  Team_6_Back_left_passenger_Init(&Team_6_B.front_passenger,
    &Team_6_DW.front_passenger, &Team_6_P.front_passenger);

  /* End of SystemInitialize for SubSystem: '<S8>/front_passenger' */
  /* End of SystemInitialize for SubSystem: '<S1>/power_window' */

  /* Start for DiscretePulseGenerator: '<S10>/Continuous Pulse Generator' */
  Team_6_DW.clockTickCounter = 0;

  /* Start for If: '<S3>/If' */
  Team_6_DW.If_ActiveSubsystem_f = -1;

  /* SystemInitialize for Triggered SubSystem: '<S10>/Triggered Subsystem' */
  /* SystemInitialize for Outport: '<S17>/Out1' incorporates:
   *  Inport: '<S17>/In1'
   */
  Team_6_B.In1_i = Team_6_P.Out1_Y0;

  /* End of SystemInitialize for SubSystem: '<S10>/Triggered Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S3>/If Action Subsystem' */
  Team_6_IfActionSubsystem_Init(&Team_6_B.IfActionSubsystem,
    &Team_6_P.IfActionSubsystem);

  /* End of SystemInitialize for SubSystem: '<S3>/If Action Subsystem' */
  /* End of SystemInitialize for SubSystem: '<S1>/External Light' */

  /* SystemInitialize for Atomic SubSystem: '<S1>/mirror' */
  /* SystemInitialize for Enabled SubSystem: '<S7>/right_mirror' */
  Team_6_left_mirror_Init(&Team_6_B.right_mirror, &Team_6_DW.right_mirror,
    &Team_6_P.right_mirror);

  /* End of SystemInitialize for SubSystem: '<S7>/right_mirror' */

  /* SystemInitialize for Enabled SubSystem: '<S7>/left_mirror' */
  Team_6_left_mirror_Init(&Team_6_B.left_mirror, &Team_6_DW.left_mirror,
    &Team_6_P.left_mirror);

  /* End of SystemInitialize for SubSystem: '<S7>/left_mirror' */
  /* End of SystemInitialize for SubSystem: '<S1>/mirror' */
}

/* Model terminate function */
void Team_6_terminate(void)
{
  /* (no terminate code required) */
}
