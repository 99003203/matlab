/*
 * Team_6_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Team_6".
 *
 * Model version              : 1.48
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan  9 17:49:04 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Team_6_private_h_
#define RTW_HEADER_Team_6_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "Team_6.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

/* Used by FromWorkspace Block: '<S31>/FromWs' */
#ifndef rtInterpolate
# define rtInterpolate(v1,v2,f1,f2)    (((v1)==(v2))?((double)(v1)): (((f1)*((double)(v1)))+((f2)*((double)(v2)))))
#endif

#ifndef rtRound
# define rtRound(v)                    ( ((v) >= 0) ? floor((v) + 0.5) : ceil((v) - 0.5) )
#endif

extern void Team_6_IfActionSubsystem_Init(B_IfActionSubsystem_Team_6_T *localB,
  P_IfActionSubsystem_Team_6_T *localP);
extern void Team_6_IfActionSubsystem(real_T rtu_In1,
  B_IfActionSubsystem_Team_6_T *localB);
extern void Team_6_IfActionSubsystem_f_Init(B_IfActionSubsystem_Team_6_p_T
  *localB, P_IfActionSubsystem_Team_6_j_T *localP);
extern void Team_6_IfActionSubsystem_m(real_T rtu_In1,
  B_IfActionSubsystem_Team_6_p_T *localB);
extern void Team__Horizontal_Direction_Init(B_Horizontal_Direction_Team_6_T
  *localB, DW_Horizontal_Direction_Team__T *localDW,
  P_Horizontal_Direction_Team_6_T *localP);
extern void Tea_Horizontal_Direction_Update(B_Horizontal_Direction_Team_6_T
  *localB, DW_Horizontal_Direction_Team__T *localDW);
extern void Team_6_Horizontal_Direction(real_T rtu_In1,
  B_Horizontal_Direction_Team_6_T *localB, DW_Horizontal_Direction_Team__T
  *localDW, P_Horizontal_Direction_Team_6_T *localP);
extern void Team_6_IfActionSubsystem_e(real_T rtu_In1, real_T *rty_Out1);
extern void Team_6_left_mirror_Init(B_left_mirror_Team_6_T *localB,
  DW_left_mirror_Team_6_T *localDW, P_left_mirror_Team_6_T *localP);
extern void Team_6_left_mirror_Disable(DW_left_mirror_Team_6_T *localDW);
extern void Team_6_left_mirror(real_T rtu_Enable, real_T rtu_Input2,
  B_left_mirror_Team_6_T *localB, DW_left_mirror_Team_6_T *localDW,
  P_left_mirror_Team_6_T *localP);
extern void Team_6_Back_left_passenger_Init(B_Back_left_passenger_Team_6_T
  *localB, DW_Back_left_passenger_Team_6_T *localDW,
  P_Back_left_passenger_Team_6_T *localP);
extern void Tea_Back_left_passenger_Disable(DW_Back_left_passenger_Team_6_T
  *localDW);
extern void Team_6_Back_left_passenger(boolean_T rtu_Enable, real_T rtu_Input,
  B_Back_left_passenger_Team_6_T *localB, DW_Back_left_passenger_Team_6_T
  *localDW, P_Back_left_passenger_Team_6_T *localP);

#endif                                 /* RTW_HEADER_Team_6_private_h_ */
