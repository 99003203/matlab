/*
 * Team_6_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Team_6".
 *
 * Model version              : 1.48
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sat Jan  9 17:49:04 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "Team_6.h"
#include "Team_6_private.h"

/* Block parameters (default storage) */
P_Team_6_T Team_6_P = {
  /* Expression: 1
   * Referenced by: '<S10>/Continuous Pulse Generator'
   */
  1.0,

  /* Computed Parameter: ContinuousPulseGenerator_Period
   * Referenced by: '<S10>/Continuous Pulse Generator'
   */
  2.0,

  /* Computed Parameter: ContinuousPulseGenerator_Duty
   * Referenced by: '<S10>/Continuous Pulse Generator'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S10>/Continuous Pulse Generator'
   */
  0.0,

  /* Computed Parameter: Output1_Y0
   * Referenced by: '<S23>/Output1'
   */
  0.0,

  /* Computed Parameter: Output2_Y0
   * Referenced by: '<S34>/Output2'
   */
  0.0,

  /* Computed Parameter: Output3_Y0
   * Referenced by: '<S35>/Output3'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S19>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S19>/Constant1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S19>/Constant2'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S19>/Constant3'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S20>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S20>/Constant1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S21>/Constant1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S42>/Cond_check3'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S42>/Cond_check1'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S42>/Cond_check'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S42>/Unit Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S42>/Unit Delay1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S50>/Cond_check3'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S50>/Cond_check1'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S50>/Cond_check'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S50>/Unit Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S50>/Unit Delay1'
   */
  0.0,

  /* Expression: 20
   * Referenced by: '<S57>/Input Gain'
   */
  20.0,

  /* Expression: 1
   * Referenced by: '<S57>/Signal Generator2'
   */
  1.0,

  /* Expression: 3
   * Referenced by: '<S57>/Signal Generator2'
   */
  3.0,

  /* Expression: 1
   * Referenced by: '<S57>/Signal Generator1'
   */
  1.0,

  /* Expression: 2
   * Referenced by: '<S57>/Signal Generator1'
   */
  2.0,

  /* Expression: 1
   * Referenced by: '<S57>/Signal Generator'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S57>/Signal Generator'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S57>/Signal Generator3'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S57>/Signal Generator3'
   */
  1.0,

  /* Expression: 20
   * Referenced by: '<S58>/Input Gain'
   */
  20.0,

  /* Expression: 1
   * Referenced by: '<S58>/Signal Generator2'
   */
  1.0,

  /* Expression: 3
   * Referenced by: '<S58>/Signal Generator2'
   */
  3.0,

  /* Expression: 1
   * Referenced by: '<S58>/Signal Generator1'
   */
  1.0,

  /* Expression: 2
   * Referenced by: '<S58>/Signal Generator1'
   */
  2.0,

  /* Expression: 1
   * Referenced by: '<S58>/Signal Generator'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S58>/Signal Generator'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S58>/Signal Generator3'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S58>/Signal Generator3'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S79>/Short_Up_ip'
   */
  1.0,

  /* Expression: -1
   * Referenced by: '<S79>/Short_Down_ip'
   */
  -1.0,

  /* Expression: 2
   * Referenced by: '<S79>/Long_Up_ip'
   */
  2.0,

  /* Expression: -2
   * Referenced by: '<S79>/Long_Down_ip'
   */
  -2.0,

  /* Expression: 0
   * Referenced by: '<S79>/default'
   */
  0.0,

  /* Computed Parameter: Merge_InitialOutput
   * Referenced by: '<S79>/Merge'
   */
  0.0,

  /* Computed Parameter: Out1_Y0
   * Referenced by: '<S17>/Out1'
   */
  0,

  /* Start of '<S8>/front_passenger' */
  {
    /* Expression: 2
     * Referenced by: '<S80>/Constant'
     */
    2.0,

    /* Expression: 1
     * Referenced by: '<S80>/Constant1'
     */
    1.0,

    /* Expression: -1
     * Referenced by: '<S80>/Constant2'
     */
    -1.0,

    /* Expression: -2
     * Referenced by: '<S80>/Constant3'
     */
    -2.0,

    /* Expression: 0
     * Referenced by: '<S80>/Constant4'
     */
    0.0,

    /* Computed Parameter: Merge_InitialOutput
     * Referenced by: '<S80>/Merge'
     */
    0.0
  }
  ,

  /* End of '<S8>/front_passenger' */

  /* Start of '<S8>/Back_right_passenger' */
  {
    /* Expression: 2
     * Referenced by: '<S78>/Constant'
     */
    2.0,

    /* Expression: 1
     * Referenced by: '<S78>/Constant1'
     */
    1.0,

    /* Expression: -1
     * Referenced by: '<S78>/Constant2'
     */
    -1.0,

    /* Expression: -2
     * Referenced by: '<S78>/Constant3'
     */
    -2.0,

    /* Expression: 0
     * Referenced by: '<S78>/Constant4'
     */
    0.0,

    /* Computed Parameter: Merge_InitialOutput
     * Referenced by: '<S78>/Merge'
     */
    0.0
  }
  ,

  /* End of '<S8>/Back_right_passenger' */

  /* Start of '<S8>/Back_left_passenger' */
  {
    /* Expression: 2
     * Referenced by: '<S77>/Constant'
     */
    2.0,

    /* Expression: 1
     * Referenced by: '<S77>/Constant1'
     */
    1.0,

    /* Expression: -1
     * Referenced by: '<S77>/Constant2'
     */
    -1.0,

    /* Expression: -2
     * Referenced by: '<S77>/Constant3'
     */
    -2.0,

    /* Expression: 0
     * Referenced by: '<S77>/Constant4'
     */
    0.0,

    /* Computed Parameter: Merge_InitialOutput
     * Referenced by: '<S77>/Merge'
     */
    0.0
  }
  ,

  /* End of '<S8>/Back_left_passenger' */

  /* Start of '<S7>/right_mirror' */
  {
    /* Expression: 1
     * Referenced by: '<S68>/Constant1'
     */
    1.0,

    /* Expression: -1
     * Referenced by: '<S68>/Constant2'
     */
    -1.0,

    /* Expression: 2
     * Referenced by: '<S68>/Constant3'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S68>/Constant4'
     */
    0.0,

    /* Start of '<S67>/If Action Subsystem3' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S76>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S67>/If Action Subsystem3' */

    /* Start of '<S67>/If Action Subsystem1' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S74>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S67>/If Action Subsystem1' */

    /* Start of '<S67>/If Action Subsystem2' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S75>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S67>/If Action Subsystem2' */

    /* Start of '<S67>/If Action Subsystem' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S73>/Out1'
       */
      0.0
    }
    /* End of '<S67>/If Action Subsystem' */
  }
  ,

  /* End of '<S7>/right_mirror' */

  /* Start of '<S7>/left_mirror' */
  {
    /* Expression: 1
     * Referenced by: '<S67>/Constant1'
     */
    1.0,

    /* Expression: -1
     * Referenced by: '<S67>/Constant2'
     */
    -1.0,

    /* Expression: 2
     * Referenced by: '<S67>/Constant3'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S67>/Constant4'
     */
    0.0,

    /* Start of '<S67>/If Action Subsystem3' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S72>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S67>/If Action Subsystem3' */

    /* Start of '<S67>/If Action Subsystem1' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S70>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S67>/If Action Subsystem1' */

    /* Start of '<S67>/If Action Subsystem2' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S71>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S67>/If Action Subsystem2' */

    /* Start of '<S67>/If Action Subsystem' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S69>/Out1'
       */
      0.0
    }
    /* End of '<S67>/If Action Subsystem' */
  }
  ,

  /* End of '<S7>/left_mirror' */

  /* Start of '<S50>/If Action Subsystem2' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S56>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S50>/If Action Subsystem2' */

  /* Start of '<S50>/If Action Subsystem1' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S55>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S50>/If Action Subsystem1' */

  /* Start of '<S50>/If Action Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S54>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S50>/If Action Subsystem' */

  /* Start of '<S40>/Horizontal_Direction' */
  {
    /* Expression: 0
     * Referenced by: '<S49>/Cond_check3'
     */
    0.0,

    /* Expression: -1
     * Referenced by: '<S49>/Cond_check1'
     */
    -1.0,

    /* Expression: 1
     * Referenced by: '<S49>/Cond_check'
     */
    1.0,

    /* Expression: 0
     * Referenced by: '<S49>/Unit Delay'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S49>/Unit Delay1'
     */
    0.0,

    /* Start of '<S41>/If Action Subsystem2' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S53>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S41>/If Action Subsystem2' */

    /* Start of '<S41>/If Action Subsystem1' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S52>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S41>/If Action Subsystem1' */

    /* Start of '<S41>/If Action Subsystem' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S51>/Out1'
       */
      0.0
    }
    /* End of '<S41>/If Action Subsystem' */
  }
  ,

  /* End of '<S40>/Horizontal_Direction' */

  /* Start of '<S42>/If Action Subsystem2' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S48>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S42>/If Action Subsystem2' */

  /* Start of '<S42>/If Action Subsystem1' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S47>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S42>/If Action Subsystem1' */

  /* Start of '<S42>/If Action Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S46>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S42>/If Action Subsystem' */

  /* Start of '<S39>/Horizontal_Direction' */
  {
    /* Expression: 0
     * Referenced by: '<S41>/Cond_check3'
     */
    0.0,

    /* Expression: -1
     * Referenced by: '<S41>/Cond_check1'
     */
    -1.0,

    /* Expression: 1
     * Referenced by: '<S41>/Cond_check'
     */
    1.0,

    /* Expression: 0
     * Referenced by: '<S41>/Unit Delay'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S41>/Unit Delay1'
     */
    0.0,

    /* Start of '<S41>/If Action Subsystem2' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S45>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S41>/If Action Subsystem2' */

    /* Start of '<S41>/If Action Subsystem1' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S44>/Out1'
       */
      0.0
    }
    ,

    /* End of '<S41>/If Action Subsystem1' */

    /* Start of '<S41>/If Action Subsystem' */
    {
      /* Computed Parameter: Out1_Y0
       * Referenced by: '<S43>/Out1'
       */
      0.0
    }
    /* End of '<S41>/If Action Subsystem' */
  }
  ,

  /* End of '<S39>/Horizontal_Direction' */

  /* Start of '<S21>/If Action Subsystem1' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S33>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S21>/If Action Subsystem1' */

  /* Start of '<S21>/If Action Subsystem' */
  {
    /* Computed Parameter: Output_Y0
     * Referenced by: '<S32>/Output'
     */
    0.0
  }
  ,

  /* End of '<S21>/If Action Subsystem' */

  /* Start of '<S20>/If Action Subsystem3' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S29>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S20>/If Action Subsystem3' */

  /* Start of '<S20>/If Action Subsystem2' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S28>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S20>/If Action Subsystem2' */

  /* Start of '<S20>/If Action Subsystem1' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S27>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S20>/If Action Subsystem1' */

  /* Start of '<S20>/If Action Subsystem' */
  {
    /* Computed Parameter: Output_Y0
     * Referenced by: '<S26>/Output'
     */
    0.0
  }
  ,

  /* End of '<S20>/If Action Subsystem' */

  /* Start of '<S19>/If Action Subsystem3' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S25>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S19>/If Action Subsystem3' */

  /* Start of '<S19>/If Action Subsystem2' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S24>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S19>/If Action Subsystem2' */

  /* Start of '<S19>/If Action Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S22>/Out1'
     */
    0.0
  }
  ,

  /* End of '<S19>/If Action Subsystem' */

  /* Start of '<S3>/If Action Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S11>/Out1'
     */
    0.0
  }
  /* End of '<S3>/If Action Subsystem' */
};
